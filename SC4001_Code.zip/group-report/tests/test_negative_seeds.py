import importlib.util
from pathlib import Path
import unittest

path = Path(__file__).resolve().parents[1]/'scripts/analyze_negative_seeds.py'
spec = importlib.util.spec_from_file_location('negative_seeds', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class RankingTests(unittest.TestCase):
    def test_auc_ties_and_reversal(self):
        rows = [{'label': label, 'p_positive': score} for label, score in
                [(0, .1), (1, .5), (0, .5), (1, .9)]]
        self.assertEqual(module.auc(rows), .875)
        self.assertEqual(module.auc([{**r, 'p_positive': 1-r['p_positive']} for r in rows]), .125)
        self.assertEqual(module.auc([{**r, 'p_positive': .5} for r in rows]), .5)


if __name__ == '__main__':
    unittest.main()
