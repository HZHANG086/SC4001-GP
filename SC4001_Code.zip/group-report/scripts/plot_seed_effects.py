"""Render paired A100 seed effects from the accepted per-candidate table."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]


def main():
    with (ROOT/'evidence/seeds-a100/per_candidate.csv').open() as stream:
        rows = list(csv.DictReader(stream))
    seeds = sorted({int(row['seed']) for row in rows})
    matching, selected = [], []
    for seed in seeds:
        cell = [row for row in rows if int(row['seed']) == seed]
        values = {(row['head'], row['anchor'], float(row['strength'])):
                  100 * float(row['ood_accuracy']) for row in cell}
        matching.append((values['cls', 'cls', .1] + values['mean', 'mean', .1]
                         - values['cls', 'mean', .1] - values['mean', 'cls', .1]) / 2)
        m6 = [row for row in cell if row['source_selected_m6'] == 'True']
        if len(m6) != 1:
            raise ValueError('Expected one source-selected M6 per seed')
        selected.append(100 * float(m6[0]['ood_accuracy']) - values['cls', 'none', 0])
    if len(seeds) != 15:
        raise ValueError('Expected the complete A100 cohort')
    plt.rcParams.update({'font.size': 10, 'pdf.fonttype': 42})
    fig, axes = plt.subplots(1, 2, figsize=(9, 2.6))
    for ax, values, title, color, marker in zip(
            axes, (matching, selected), ('Matching effect', 'Source-selected M6 vs. baseline'),
            ('#0072B2', '#D55E00'), ('o', 's')):
        ax.scatter(range(15), values, color=color, marker=marker, s=24)
        ax.axhline(0, color='.4', linewidth=.8)
        ax.set_xticks(range(15), [str(seed) for seed in seeds], rotation=90)
        ax.set_xlabel('Training and sampling seed')
        ax.set_ylabel('OOD accuracy difference (pp)')
        ax.set_title(title)
        ax.spines[['top', 'right']].set_visible(False)
    fig.tight_layout()
    fig.savefig(ROOT/'latex/images/08_seed_effects.pdf')
    plt.close(fig)


if __name__ == '__main__':
    main()
