"""Accept completed supplement archives without trusting extraction paths or summary metrics.

This writes only an isolated evidence directory. It does not change the report or
claim completion unless both archives, their full manifests and predictions pass.
"""
import argparse,csv,gzip,hashlib,json,math,shutil,tarfile
from pathlib import Path,PurePosixPath
import numpy as np
from scipy.stats import t


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def read(path):return json.loads(Path(path).read_text())


def unpack(archive,sidecar,dest,manifest_path):
    external=read(sidecar)
    if sha(archive)!=external['sha256'] or Path(archive).stat().st_size!=external['bytes']:raise ValueError('Outer archive verification failed')
    if dest.exists():raise ValueError('Preserve existing extraction: '+str(dest))
    dest.mkdir(parents=True)
    names=set()
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            name=PurePosixPath(member.name)
            if name.is_absolute() or '..' in name.parts or not name.parts or member.name in names or not member.isfile():raise ValueError('Unsafe/duplicate/non-file archive entry')
            if member.size>512*1024*1024:raise ValueError('Unexpected large evidence file')
            names.add(member.name);target=dest.joinpath(*name.parts);target.parent.mkdir(parents=True,exist_ok=True)
            with tar.extractfile(member) as source,target.open('xb') as output:shutil.copyfileobj(source,output)
    manifest=read(dest/manifest_path)
    if names!=set(manifest['files'])|{manifest_path}:raise ValueError('Archive/manifest inventory mismatch')
    for name,expected in manifest['files'].items():
        if sha(dest/name)!=expected:raise ValueError('Internal evidence checksum failed: '+name)
    if len(names)!=external['files']:raise ValueError('Outer file count mismatch')
    return manifest


def audit_files(root,path):
    audit=read(root/path)
    if audit['status']!='PASS':raise ValueError('Server audit did not pass')
    for name,expected in audit['files'].items():
        if sha((root/path).parent/name)!=expected:raise ValueError('Server audit output changed')
    return audit


def rows(path):
    with Path(path).open() as f:return list(csv.DictReader(f))


def audit_training(root,study,version,expected,gpu='6000 Ada'):
    local=Path(__file__).resolve().parents[2]
    protocol=Path(study)/'protocol'/(version+'.json')
    if sha(root/protocol)!=sha(local/protocol):raise ValueError('Returned protocol differs from locally frozen protocol')
    lock=read(root/study/'runs'/version/'ALL_SELECTIONS_LOCKED.json')
    if lock['protocol_sha256']!=sha(root/protocol) or len(lock['candidates'])!=expected:raise ValueError('Invalid global source lock')
    for name,entry in lock['candidates'].items():
        folder=root/study/'runs'/version/name;c=entry['candidate']
        if (folder/'COMPLETE').read_text().strip()!='FORMAL_SOURCE_ONLY_COMPLETE':raise ValueError('Nonformal completion in evidence')
        for file,checksum in entry['files'].items():
            if sha(folder/file)!=checksum:raise ValueError('Source evidence differs from frozen lock')
        cfg=read(folder/'run_config.json');val=read(folder/'validation.json')
        if cfg['candidate']!=c or cfg['fixture'] or cfg['smoke'] or cfg['epochs']!=10 or cfg['protocol_sha256']!=sha(root/protocol):raise ValueError('Incorrect training provenance')
        if val['global_step']!=c['budget']//4 or gpu not in val['gpu'] or not val['job_id']:raise ValueError('Incomplete/wrong-platform training')
        if val['weight_sha256']!=entry['weight_sha256'] or val['reload_max_abs_logit_difference']>1e-6:raise ValueError('Export verification failed')
        history=[r for r in read(folder/'history.json') if 'eval_accuracy' in r]
        if len(history)!=10 or max(r['epoch'] for r in history)!=10 or not math.isclose(max(r['eval_accuracy'] for r in history),val['eval_accuracy'],abs_tol=1e-12):raise ValueError('Incorrect epoch selection')
        split=(root/'seed-study/artifacts/data-v1/splits' if study=='seed-study' else local/'member-a/remote-records/data-v1/splits')/f'b{c["budget"]}_s{c["seed"]}.json'
        if sha(split)!=cfg['split_sha256']:raise ValueError('Source split provenance mismatch')
    return expected


def probability_metrics(records):
    # Independently written calculations from serialized raw predictions.
    y=np.array([int(r['label']) for r in records]);hard=np.array([int(r['prediction']) for r in records]);p=np.array([float(r['p_positive']) for r in records])
    if not np.isin(y,[0,1]).all() or not np.isin(hard,[0,1]).all() or not np.isfinite(p).all() or ((p<0)|(p>1)).any():raise ValueError('Invalid raw prediction')
    if ((hard!=(p>.5))&(abs(p-.5)>1e-7)).any():raise ValueError('Probability/decision disagreement')
    f1=[];recall=[]
    for label in (0,1):
        tp=np.count_nonzero((y==label)&(hard==label));fp=np.count_nonzero((y!=label)&(hard==label));fn=np.count_nonzero((y==label)&(hard!=label))
        f1.append(2*tp/max(2*tp+fp+fn,1));recall.append(tp/max(tp+fn,1))
    q=np.clip(p,1e-12,1-1e-12);conf=np.maximum(p,1-p);bins=np.minimum((conf*15).astype(int),14)
    ece=sum(float(np.mean(bins==i))*abs(float(np.mean(hard[bins==i]==y[bins==i]))-float(np.mean(conf[bins==i]))) for i in range(15) if np.any(bins==i))
    return {'accuracy':float(np.mean(y==hard)),'macro_f1':float(np.mean(f1)),'balanced_accuracy':float(np.mean(recall)),
        'brier':float(np.mean((p-y)**2)),'nll':float(np.mean(-y*np.log(q)-(1-y)*np.log1p(-q))),'ece15':ece}


def audit_predictions(root,study,version,count,canonical):
    folder=root/study/'results'/version;table=rows(folder/'per_candidate.csv');total=0
    if len(table)!=count or len({r['name'] for r in table})!=count:raise ValueError('Wrong candidate count')
    for row in table:
        for domain,n in [('imdb',25000),('yelp',5000),('amazon',5000)]:
            path=root/study/'runs'/version/row['name']/'evaluation'/f'{domain}_predictions.jsonl.gz'
            with gzip.open(path,'rt') as f:raw=[json.loads(line) for line in f]
            ids=[v['example_id'] for v in raw];labels=[v['label'] for v in raw]
            if len(raw)!=n or len(set(ids))!=n:raise ValueError('Wrong raw prediction population')
            if domain not in canonical:canonical[domain]=(ids,labels)
            if canonical[domain]!=(ids,labels):raise ValueError('Unpaired samples across methods/seeds/cohorts')
            actual=probability_metrics(raw)
            for metric,value in actual.items():
                if not math.isclose(value,float(row[domain+'_'+metric]),rel_tol=0,abs_tol=1e-12):raise ValueError('Independent raw metric mismatch')
            total+=n
        for metric in ('accuracy','macro_f1'):
            mean=(float(row['yelp_'+metric])+float(row['amazon_'+metric]))/2
            if not math.isclose(mean,float(row['ood_'+metric]),abs_tol=1e-12):raise ValueError('Wrong OOD aggregation')
    return total


def exact_flip(d):
    d=np.asarray(d,float);target=abs(d.mean());extreme=0
    for begin in range(0,2**len(d),65536):
        index=np.arange(begin,min(begin+65536,2**len(d)),dtype=np.uint64)
        signs=((index[:,None]>>np.arange(len(d),dtype=np.uint64))&1).astype(np.int8)*2-1
        values=signs@d/len(d);extreme+=np.count_nonzero(abs(values)>=target-1e-12)
    return extreme/(2**len(d))


def audit_a100(root):
    protocol=root/'seed-study/protocol/Seeds-v1.json'
    runs=root/'seed-study/runs/Seeds-v1'
    results=root/'seed-study/results/Seeds-v1'
    lock=read(runs/'ALL_SELECTIONS_LOCKED.json')
    platform_path=root/'wisteria/evidence/platform.json'
    platform=read(platform_path)
    spec=read(protocol)
    local=Path(__file__).resolve().parents[2]
    for name,expected in spec['code_sha256'].items():
        if sha(root/name)!=expected or sha(local/name)!=expected:
            raise ValueError('Frozen dependency differs from delivered code: '+name)
    lock_sha=sha(runs/'ALL_SELECTIONS_LOCKED.json')
    gpu='NVIDIA A100-SXM4-40GB'
    if gpu not in platform['gpu_stratum'] or platform['protocol_sha256']!=sha(protocol) or platform['seeds']!=spec['seeds']:
        raise ValueError('Invalid A100 platform provenance')
    for name, hashes in platform['platform_adapters'].items():
        frozen='seed-study/src/sc4001_seed/'+name
        if hashes['frozen_sha256']!=spec['code_sha256'][frozen] or sha(root/frozen)!=hashes['frozen_sha256']:
            raise ValueError('Frozen A100 source hash mismatch')
        if sha(root/'wisteria/overlay/sc4001_seed'/name)!=hashes['adapter_sha256']:
            raise ValueError('A100 adapter hash mismatch')
    gate=read(runs.parent/'JOINT_SOURCE_GATE.json')
    if gate!={'seed_protocol_sha256':sha(protocol),'seed_lock_sha256':lock_sha,
              'status':'WISTERIA_A100_ALL_SEED_SELECTIONS_LOCKED_BEFORE_TARGET','platform_sha256':sha(platform_path)}:
        raise ValueError('A100 source gate mismatch')
    table=rows(results/'per_candidate.csv')
    by_name={r['name']:r for r in table}
    if len(table)!=120 or set(by_name)!=set(lock['eval_names']):
        raise ValueError('Incorrect A100 evaluation population')
    entries={}
    for name,row in by_name.items():
        candidate=lock['candidates'][name]['candidate']
        seed=int(row['seed']);strength=float(row['strength'])
        if (seed,row['head'],row['anchor'],strength)!=(candidate['seed'],candidate['head'],candidate['anchor'],candidate['strength']):
            raise ValueError('A100 candidate provenance mismatch')
        folder=runs/name/'evaluation'
        evaluation=read(folder/'EVALUATION_COMPLETE.json')
        if evaluation['gpu']!=gpu or not evaluation['job_id'] or evaluation['lock_sha256']!=lock_sha or evaluation['candidate']!=candidate or evaluation['weight_sha256']!=lock['candidates'][name]['weight_sha256']:
            raise ValueError('A100 evaluation provenance mismatch')
        for artifact, checksum in evaluation['files'].items():
            if sha(folder/artifact)!=checksum:raise ValueError('A100 evaluation checksum mismatch')
        key=(seed,row['head'],row['anchor'],strength)
        if key in entries:raise ValueError('Duplicate A100 comparison cell')
        entries[key]=100*float(row['ood_accuracy'])
    seedwise=[]
    for seed in spec['seeds']:
        cls=entries[seed,'cls','cls',.1]-entries[seed,'cls','mean',.1]
        mean=entries[seed,'mean','mean',.1]-entries[seed,'mean','cls',.1]
        selected=by_name[lock['source_selected_m6'][str(seed)]]
        if int(selected['seed'])!=seed or (selected['head'],selected['anchor'])!=('cls','mean'):
            raise ValueError('Incorrect source-selected M6')
        seedwise.append({
            'cls_match_minus_mismatch':cls,
            'mean_match_minus_mismatch':mean,
            'matched_mean_minus_mismatched_mean':(cls+mean)/2,
            'source_selected_m6_minus_cls_baseline':100*float(selected['ood_accuracy'])-entries[seed,'cls','none',0],
        })
    archived={r['comparison']:r for r in rows(results/'paired_effects_new15.csv') if r['metric']=='ood_accuracy'}
    checked={}
    for key in seedwise[0]:
        d=np.array([r[key] for r in seedwise])
        n=len(d);mean=d.mean();sd=d.std(ddof=1);half=t.ppf(.975,n-1)*sd/np.sqrt(n)
        checked[key]={'mean':float(mean),'sample_sd':float(sd),'ci95_low':float(mean-half),'ci95_high':float(mean+half),
                      'p_signflip_exact':float(exact_flip(d)),'n_seeds':n}
    primary=('matched_mean_minus_mismatched_mean','source_selected_m6_minus_cls_baseline')
    first,second=sorted(primary,key=lambda k:checked[k]['p_signflip_exact'])
    checked[first]['p_holm_within_family']=min(1.,2*checked[first]['p_signflip_exact'])
    checked[second]['p_holm_within_family']=max(checked[first]['p_holm_within_family'],checked[second]['p_signflip_exact'])
    for key,metrics in checked.items():
        for metric,value in metrics.items():
            if not math.isclose(value,float(archived[key][metric]),rel_tol=0,abs_tol=1e-10):
                raise ValueError('A100 paired contrast mismatch: '+key+'/'+metric)
    return checked


def audit_primary(seed_root):
    base=seed_root/'seed-study/results/Seeds-v1'
    points=rows(base/'seedwise_primary_effects.csv');effects=rows(base/'paired_effects_all_cohorts.csv')
    mapping={'matched_mean_minus_mismatched_mean':'matching_effect_pp','source_selected_m6_minus_cls_baseline':'source_selected_m6_minus_baseline_pp'}
    checked=0
    for cohort,n in [('original_5_descriptive',5),('new_15_primary',15),('pooled_20_sensitivity',20)]:
        chosen=[r for r in points if cohort=='pooled_20_sensitivity' or r['cohort']==('original_5' if n==5 else 'new_15')]
        if len(chosen)!=n:raise ValueError('Incorrect inference sample size')
        family=[]
        for comparison,column in mapping.items():
            d=np.array([float(r[column]) for r in chosen]);mean=d.mean();sd=d.std(ddof=1);half=t.ppf(.975,n-1)*sd/np.sqrt(n)
            matched=[r for r in effects if r['cohort']==cohort and r['metric']=='ood_accuracy' and r['comparison']==comparison]
            if len(matched)!=1:raise ValueError('Missing/duplicate primary result')
            r=matched[0];values={'mean':mean,'sample_sd':sd,'ci95_low':mean-half,'ci95_high':mean+half,'p_signflip_exact':exact_flip(d),'n_seeds':n}
            for key,value in values.items():
                if not math.isclose(float(r[key]),value,rel_tol=0,abs_tol=1e-10):raise ValueError('Independent paired statistic mismatch')
            family.append(r);checked+=1
        family.sort(key=lambda r:float(r['p_signflip_exact']));previous=0
        for i,r in enumerate(family):
            adjusted=min(1,max(previous,(2-i)*float(r['p_signflip_exact'])));previous=adjusted
            if not math.isclose(adjusted,float(r['p_holm_within_family']),abs_tol=1e-12):raise ValueError('Primary multiplicity mismatch')
    return checked


def audit_pool_focal(pool_root):
    base=pool_root/'pooling-study/results/Pooling-v1'
    by_group={}
    for r in rows(base/'per_candidate.csv'):
        if int(r['budget'])!=6400 or float(r['strength'])!=.1:
            continue
        group=by_group.setdefault((r['head'],r['anchor']),{})
        seed=int(r['seed'])
        if seed in group:raise ValueError('Duplicate pooling contrast seed')
        group[seed]=float(r['ood_accuracy'])*100
    keys=(('cls','cls'),('mean','mean'),('cls','mean'),('mean','cls'))
    frozen_seeds=set(read(pool_root/'pooling-study/protocol/Pooling-v1.json')['seeds'])
    if set(by_group)!=set(keys) or any(set(g)!=frozen_seeds for g in by_group.values()):
        raise ValueError('Incomplete pooling contrast pairing')
    cc,mm,cm,mc=(np.array([by_group[key][s] for s in sorted(frozen_seeds)]) for key in keys)
    d=(cc+mm-cm-mc)/2
    mean=d.mean();sd=d.std(ddof=1);half=t.ppf(.975,len(d)-1)*sd/np.sqrt(len(d))
    actual={'mean':mean,'ci95_low':mean-half,'ci95_high':mean+half,'p_signflip_exact':exact_flip(d)}
    archived=read(base/'primary_contrast.json')
    for k,v in actual.items():
        if not math.isclose(float(archived[k]),v,rel_tol=0,abs_tol=1e-10):
            raise ValueError('Independent pooling contrast mismatch: '+k)
    return {k:float(v) for k,v in actual.items()}


def main():
    p=argparse.ArgumentParser();p.add_argument('--pooling',type=Path,required=True);p.add_argument('--seeds',type=Path,help='Omit to accept Pooling-v1 independently.');p.add_argument('--dest',type=Path,required=True)
    a=p.parse_args()
    if a.dest.exists():raise ValueError('Choose a new acceptance destination')
    pool_root=a.dest/'pooling';seed_root=a.dest/'seeds'
    archives=[(a.pooling,pool_root,'pooling-study/RETURN_MANIFEST.json')]
    if a.seeds is not None:archives.append((a.seeds,seed_root,'seed-study/RETURN_MANIFEST.json'))
    for archive,dest,manifest in archives:
        unpack(archive,archive.with_suffix('.manifest.json'),dest,manifest)
    audit_files(pool_root,Path('pooling-study/results/Pooling-v1/AUDIT.json'))
    trainings=audit_training(pool_root,'pooling-study','Pooling-v1',210)
    canonical={};total=audit_predictions(pool_root,'pooling-study','Pooling-v1',210,canonical)
    focal=audit_pool_focal(pool_root)
    comparisons=0;a100=None
    if a.seeds is not None:
        audit_files(seed_root,Path('seed-study/results/Seeds-v1/AUDIT_NEW15.json'))
        if (seed_root/'wisteria/evidence/platform.json').is_file():
            trainings+=audit_training(seed_root,'seed-study','Seeds-v1',150,gpu='NVIDIA A100-SXM4-40GB')
            a100=audit_a100(seed_root)
            comparisons=2
        else:
            audit_files(seed_root,Path('seed-study/results/Seeds-v1/AUDIT_FINAL.json'))
            trainings+=audit_training(seed_root,'seed-study','Seeds-v1',150)
            comparisons=audit_primary(seed_root)
        total+=audit_predictions(seed_root,'seed-study','Seeds-v1',120,canonical)
    result={'status':'PASS','formal_training_records_checked':trainings,'prediction_rows_independently_recomputed':total,'primary_cohort_contrasts_checked':comparisons,
        'pooling_focal_recomputed':focal,'pooling_archive_sha256':sha(a.pooling),'seed_archive_sha256':sha(a.seeds) if a.seeds is not None else None,
        'scope':'Pooling-v1 and Seeds-v1' if a.seeds is not None else 'Pooling-v1 only'}
    if a100 is not None:result['a100_new15_contrasts_recomputed']=a100
    (a.dest/'ACCEPTANCE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))


if __name__=='__main__':main()
