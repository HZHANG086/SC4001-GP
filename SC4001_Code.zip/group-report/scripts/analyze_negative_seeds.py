"""Describe selected-M6 failures using archived validation and paired predictions.

All 15 seeds are analyzed before identifying the three negative outcomes.
This is post-hoc descriptive analysis. It never selects new models or thresholds.
"""
import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path


def auc(records):
    """Mann–Whitney AUC, giving half credit to equal probability scores."""
    ordered = sorted(records, key=lambda row: row['p_positive'])
    below_negative = 0
    concordant = 0.
    index = 0
    while index < len(ordered):
        end = index + 1
        while end < len(ordered) and ordered[end]['p_positive'] == ordered[index]['p_positive']:
            end += 1
        positives = sum(row['label'] == 1 for row in ordered[index:end])
        negatives = end - index - positives
        concordant += positives * (below_negative + .5 * negatives)
        below_negative += negatives
        index = end
    positives = sum(row['label'] == 1 for row in ordered)
    return concordant / (positives * (len(ordered) - positives))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--accepted-seeds', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root = args.accepted_seeds
    manifest = json.loads((root/'seed-study/RETURN_MANIFEST.json').read_text())
    inputs = {}

    def read_file(relative):
        data = (root/relative).read_bytes()
        checksum = hashlib.sha256(data).hexdigest()
        if manifest['files'][relative] != checksum:
            raise ValueError('Evidence checksum mismatch: ' + relative)
        inputs[relative] = checksum
        return data

    def read_json(relative):
        return json.loads(read_file(relative))

    run_root = 'seed-study/runs/Seeds-v1/'
    lock = read_json(run_root+'ALL_SELECTIONS_LOCKED.json')
    spec = read_json('seed-study/protocol/Seeds-v1.json')
    results, classes, strengths, curves = [], [], [], []
    regressions = {}
    for seed in spec['seeds']:
        lr = read_json(run_root+f'LR_LOCK-b6400-s{seed}.json')['winner']['name']
        selected = lock['source_selected_m6'][str(seed)]
        candidates = [lr] + [name for name, item in lock['candidates'].items()
                            if item['candidate']['seed'] == seed
                            and item['candidate']['head'] == 'cls'
                            and item['candidate']['anchor'] == 'mean']
        validation = {}
        for name in candidates:
            folder = run_root+name+'/'
            val = read_json(folder+'validation.json')
            history = [row for row in read_json(folder+'history.json') if 'eval_accuracy' in row]
            best = max(history, key=lambda row: row['eval_accuracy'])
            if best['eval_accuracy'] != val['eval_accuracy']:
                raise ValueError('Selected validation score mismatch')
            step = int(Path(val['best_checkpoint']).name.split('-')[-1])
            if step != best['step']:
                raise ValueError('Checkpoint did not use earliest best validation epoch')
            validation[name] = val
            metrics = read_json(folder+'evaluation/metrics.json')
            candidate = lock['candidates'][name]['candidate']
            strengths.append({
                'seed': seed, 'name': name, 'selected_m6': name == selected,
                'strength': candidate['strength'], 'lr': candidate['lr'],
                'selected_epoch': best['epoch'], 'validation_accuracy': val['eval_accuracy'],
                'validation_loss': val['eval_loss'],
                **{d+'_accuracy': metrics[d]['accuracy'] for d in ('imdb','yelp','amazon')},
                'ood_accuracy': metrics['ood_accuracy'],
            })
            curves.extend({'seed': seed, 'name': name, **row} for row in history)
        base, m6 = validation[lr], validation[selected]
        for domain in ('imdb','yelp','amazon'):
            paired = []
            for name in (lr, selected):
                data = read_file(run_root+name+f'/evaluation/{domain}_predictions.jsonl.gz')
                paired.append([json.loads(line) for line in gzip.decompress(data).splitlines()])
            left, right = paired
            if [(r['example_id'],r['label']) for r in left] != [(r['example_id'],r['label']) for r in right]:
                raise ValueError('Unpaired predictions')
            fixes, broken = [], []
            for a, b in zip(left, right):
                if a['prediction'] != a['label'] and b['prediction'] == b['label']:
                    fixes.append(b)
                if a['prediction'] == a['label'] and b['prediction'] != b['label']:
                    broken.append(b)
            regressions[seed, domain] = {r['example_id'] for r in broken}
            results.append({
                'seed': seed, 'domain': domain, 'n': len(left),
                'strength': lock['candidates'][selected]['candidate']['strength'],
                'baseline_epoch': int(Path(base['best_checkpoint']).name.split('-')[-1]) // 160,
                'm6_epoch': int(Path(m6['best_checkpoint']).name.split('-')[-1]) // 160,
                'validation_gain_pp': 100*(m6['eval_accuracy']-base['eval_accuracy']),
                'baseline_accuracy': sum(a['prediction']==a['label'] for a in left)/len(left),
                'm6_accuracy': sum(b['prediction']==b['label'] for b in right)/len(right),
                'baseline_auc': auc(left), 'm6_auc': auc(right),
                'mean_probability_shift': sum(b['p_positive']-a['p_positive'] for a,b in zip(left,right))/len(left),
                'positive_prediction_increase': sum(b['prediction']-a['prediction'] for a,b in zip(left,right)),
                'accuracy_gain_pp': 100*(len(fixes)-len(broken))/len(left),
                'fixes': len(fixes), 'regressions': len(broken),
                'regressions_confidence_ge_90': sum(max(r['p_positive'],1-r['p_positive'])>=.9 for r in broken),
            })
            for label in (0, 1):
                a = [r for r in left if r['label']==label]
                b = [r for r in right if r['label']==label]
                classes.append({
                    'seed':seed, 'domain':domain, 'label':label, 'n':len(a),
                    'baseline_errors':sum(r['prediction']!=label for r in a),
                    'm6_errors':sum(r['prediction']!=label for r in b),
                    'fixes':sum(r['label']==label for r in fixes),
                    'regressions':sum(r['label']==label for r in broken),
                })
    negative = [s for s in spec['seeds'] if sum(
        r['accuracy_gain_pp'] for r in results if r['seed']==s and r['domain']!='imdb') < 0]
    overlap = []
    for domain in ('yelp','amazon'):
        for index, first in enumerate(negative):
            for second in negative[index+1:]:
                a,b=regressions[first,domain],regressions[second,domain]
                overlap.append({'domain':domain,'seed_a':first,'seed_b':second,
                                'intersection':len(a & b),'union':len(a | b)})
    args.out.mkdir(parents=True, exist_ok=False)
    for name, rows in [('paired_errors',results),('class_errors',classes),
                       ('candidate_diagnostics',strengths),('validation_curves',curves),
                       ('negative_regression_overlap',overlap)]:
        with (args.out/(name+'.csv')).open('w') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    record={'status':'PASS','seeds_analyzed':spec['seeds'],'negative_seeds':negative,
            'scope':'Post-hoc descriptive diagnostics using all 15 seeds; no model reselection.',
            'input_sha256':inputs,
            'output_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in args.out.glob('*.csv')}}
    (args.out/'AUDIT.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'status':'PASS','negative_seeds':negative,'input_files':len(inputs)}))


if __name__ == '__main__':
    main()
