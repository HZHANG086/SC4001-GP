"""Audit all new predictions and report new-15 primary / pooled-20 sensitivity separately."""
import argparse,gzip,json
from pathlib import Path
import numpy as np
import pandas as pd
from sc4001_c.common import load,dump,digest,write_csv
from sc4001_c.stats import probability_metrics
from sc4001_pool.evaluate import complete_ok
from .common import ROOT,PROTOCOL,specification
from .inference import effects

OUT=Path('seed-study/results/Seeds-v1')


def audit_new():
    spec=specification();lock=load(ROOT/'ALL_SELECTIONS_LOCKED.json');lock_sha=digest(ROOT/'ALL_SELECTIONS_LOCKED.json')
    gate=load('seed-study/runs/JOINT_SOURCE_GATE.json')
    if gate['seed_lock_sha256']!=lock_sha:raise ValueError('Global gate mismatch')
    if OUT.exists():raise ValueError('Preserve existing analysis before any retry')
    OUT.mkdir(parents=True);records=[];cka=[];replays=[];canonical={};total=0
    for name in lock['eval_names']:
        entry=lock['candidates'][name];folder=ROOT/name/'evaluation';complete_ok(folder,lock_sha)
        saved=load(folder/'metrics.json');row={**entry['candidate'],'source_selected_m6':name in lock['source_selected_m6'].values()}
        for d in ('imdb','yelp','amazon'):
            with gzip.open(folder/f'{d}_predictions.jsonl.gz','rt') as f:pred=[json.loads(line) for line in f]
            ids=[r['example_id'] for r in pred];y=np.array([r['label'] for r in pred]);p=np.array([r['p_positive'] for r in pred]);hard=np.array([r['prediction'] for r in pred])
            expected=25000 if d=='imdb' else 5000
            if len(ids)!=expected or len(set(ids))!=expected:raise ValueError('Wrong identities/counts')
            if not np.isfinite(p).all() or ((p<0)|(p>1)).any() or not np.isin(y,[0,1]).all() or not np.isin(hard,[0,1]).all():raise ValueError('Invalid predictions')
            if ((hard!=(p>.5))&(abs(p-.5)>1e-7)).any():raise ValueError('Decision probability mismatch')
            if d in canonical:
                old_ids,old_y=canonical[d]
                if ids!=old_ids or not np.array_equal(y,old_y):raise ValueError('Not paired test examples')
            else:canonical[d]=(ids,y)
            metrics=probability_metrics(y,hard,p)
            for key,value in metrics.items():
                if abs(value-saved[d][key])>1e-12:raise ValueError('Metric replay failed')
                row[d+'_'+key]=value
            total+=len(ids)
        for m in ('accuracy','macro_f1'):row['ood_'+m]=(row['yelp_'+m]+row['amazon_'+m])/2
        records.append(row);cka.append(pd.read_csv(folder/'cka.csv'))
        replays.extend({'name':name,**r} for r in load(folder/'probability_replay.json'))
    if len(records)!=120 or total!=4200000:raise ValueError('Incomplete new cohort')
    df=pd.DataFrame(records);df.to_csv(OUT/'per_candidate.csv',index=False)
    seed_effects=effects(df,spec['seeds'],'new_15_primary',lock['source_selected_m6'])
    write_csv(OUT/'paired_effects_new15.csv',seed_effects)
    summary=df.groupby(['head','anchor','strength'])[['imdb_accuracy','yelp_accuracy','amazon_accuracy','ood_accuracy','ood_macro_f1']].agg(['mean','std','count'])
    summary.columns=['_'.join(v) for v in summary.columns];summary.to_csv(OUT/'summary_new15.csv')
    all_cka=pd.concat(cka,ignore_index=True)
    if len(all_cka)!=9360 or len(replays)!=360:raise ValueError('Incomplete diagnostics')
    if max(r['max_abs_probability_difference'] for r in replays)>1e-4:raise ValueError('Replay failure')
    all_cka.to_csv(OUT/'cka_all.csv',index=False)
    all_cka.groupby(['head','anchor','strength','domain','pooling','layer'])[['linear_cka','debiased_linear_cka','shuffled_linear_cka','cosine_distance']].mean().to_csv(OUT/'cka_summary.csv')
    write_csv(OUT/'probability_replays.csv',replays)
    dump(OUT/'canonical_test_ids.json',{d:{'ids':ids,'labels':y.tolist()} for d,(ids,y) in canonical.items()})
    dump(OUT/'AUDIT_NEW15.json',{'status':'PASS','formal_trainings':150,'evaluated_candidates':120,'prediction_rows':total,
        'cka_rows':len(all_cka),'protocol_sha256':digest(PROTOCOL),'lock_sha256':lock_sha,
        'files':{str(p.relative_to(OUT)):digest(p) for p in sorted(OUT.iterdir()) if p.is_file()}})
    print('NEW_15_AUDIT_PASS',flush=True)


def verify_audit(folder,filename):
    record=load(folder/filename)
    if record['status']!='PASS':raise ValueError('Missing valid audit')
    for name,sha in record['files'].items():
        if digest(folder/name)!=sha:raise ValueError('Previously audited output changed')


def combine():
    spec=specification();verify_audit(OUT,'AUDIT_NEW15.json')
    original=Path('pooling-study/results/Pooling-v1');verify_audit(original,'AUDIT.json')
    from sc4001_pool.common import ROOT as OLD_ROOT
    lock=load(ROOT/'ALL_SELECTIONS_LOCKED.json');old_lock=load(OLD_ROOT/'ALL_SELECTIONS_LOCKED.json')
    gate=load('seed-study/runs/JOINT_SOURCE_GATE.json')
    if gate['pooling_lock_sha256']!=digest(OLD_ROOT/'ALL_SELECTIONS_LOCKED.json'):raise ValueError('Original lock changed')
    new=pd.read_csv(OUT/'per_candidate.csv');old=pd.read_csv(original/'per_candidate.csv')
    # Only the exact fixed-strength factorial and the original M6 lambda candidates.
    old=old[(old.budget==6400)&((old.anchor=='none')|(old.strength==.1)|((old['head']=='cls')&(old.anchor=='mean')))].copy()
    if len(old)!=40 or sorted(old.seed.unique())!=sorted(spec['original_seeds']):raise ValueError('Wrong original cohort')
    old_m6={}
    for name in old_lock['selected_names']:
        c=old_lock['candidates'][name]['candidate']
        if c['budget']==6400 and (c['head'],c['anchor'])==('cls','mean'):old_m6[str(c['seed'])]=name
    if len(old_m6)!=5:raise ValueError('Original source-selected M6 missing')
    # Independently verify that both cohorts were evaluated on identical ordered data.
    canon=load(OUT/'canonical_test_ids.json')
    first=OLD_ROOT/old.iloc[0]['name']/'evaluation'
    for d in ('imdb','yelp','amazon'):
        with gzip.open(first/f'{d}_predictions.jsonl.gz','rt') as f:rows=[json.loads(v) for v in f]
        if [r['example_id'] for r in rows]!=canon[d]['ids'] or [r['label'] for r in rows]!=canon[d]['labels']:raise ValueError('Cross-cohort test mismatch')
    old['cohort']='original_5';new['cohort']='new_15';pooled=pd.concat([old,new],ignore_index=True)
    if len(pooled)!=160 or len(pooled.seed.unique())!=20:raise ValueError('Pooled count mismatch')
    pooled.to_csv(OUT/'per_candidate_pooled20.csv',index=False)
    all_effects=effects(old,spec['original_seeds'],'original_5_descriptive',old_m6)
    all_effects+=effects(new,spec['seeds'],'new_15_primary',lock['source_selected_m6'])
    all_effects+=effects(pooled,spec['original_seeds']+spec['seeds'],'pooled_20_sensitivity',{**old_m6,**lock['source_selected_m6']})
    write_csv(OUT/'paired_effects_all_cohorts.csv',all_effects)
    # Record paired seedwise differences as well as aggregate tests.
    points=[]
    for df,cohort,m6map in ((old,'original_5',old_m6),(new,'new_15',lock['source_selected_m6'])):
        for seed in sorted(df.seed.unique()):
            cell=df[df.seed==seed];v={}
            for h in ('cls','mean'):
                for a in ('none','cls','mean'):
                    row=cell[(cell['head']==h)&(cell.anchor==a)&(cell.strength==(0 if a=='none' else .1))]
                    if len(row)!=1:raise ValueError('Pairing failure')
                    v[h,a]=float(row.iloc[0].ood_accuracy)*100
            selected=float(cell[cell.name==m6map[str(seed)]].iloc[0].ood_accuracy)*100
            points.append({'seed':int(seed),'cohort':cohort,'matching_effect_pp':(v['cls','cls']+v['mean','mean']-v['cls','mean']-v['mean','cls'])/2,
                'source_selected_m6_minus_baseline_pp':selected-v['cls','none']})
    write_csv(OUT/'seedwise_primary_effects.csv',points)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
    fig,axes=plt.subplots(1,2,figsize=(10,3.5))
    for ax,key,title in zip(axes,('matching_effect_pp','source_selected_m6_minus_baseline_pp'),('Pooling matching effect','Source-selected M6 minus baseline')):
        for cohort,color,marker in (('original_5','#0072B2','o'),('new_15','#D55E00','s')):
            selected=[(i,r) for i,r in enumerate(points) if r['cohort']==cohort]
            ax.scatter([i for i,r in selected],[r[key] for i,r in selected],color=color,marker=marker,label=cohort.replace('_',' '))
        ax.axhline(0,color='.5',lw=.8);ax.set_title(title);ax.set_xlabel('Prespecified seed index');ax.set_ylabel('OOD accuracy difference (pp)')
        ax.spines[['top','right']].set_visible(False)
    axes[0].legend(frameon=False);fig.tight_layout();fig.savefig(OUT/'primary_seed_effects.pdf');fig.savefig(OUT/'primary_seed_effects.png',dpi=180);plt.close(fig)
    primary=[r for r in all_effects if r['cohort']=='new_15_primary' and r['family']=='primary_accuracy_2']
    text=['# Additional-seed follow-up: actual results','',
        'Budget 6400 only. New 15 seeds are the primary added cohort; the original 5 and pooled 20 are reported separately. The target datasets were previously seen in the ABC investigation, so this is not independent held-out confirmation.',
        'Two co-primary OOD-accuracy contrasts use a Holm family of two. The other six accuracy contrasts and eight macro-F1 contrasts use separate declared families. Approximate paired-t intervals do not guarantee nominal coverage; sign-flip tests require paired exchangeability/symmetry under the null.',
        'The 20-seed sensitivity includes original five learning-rate choices inherited from V100 source searches, while new searches and all new study models use Ada. Do not silently treat platform differences in upstream selection as absent.','']
    for r in primary:text.append(f"- {r['comparison']}: {r['mean']:+.3f} pp; approximate 95% interval [{r['ci95_low']:+.3f}, {r['ci95_high']:+.3f}]; exact p={r['p_signflip_exact']:.6f}; Holm p={r['p_holm_within_family']:.6f}.")
    text+=['','Report both matching directions and baseline-adjusted changes before making a mechanism claim. A nonsignificant result does not establish equivalence. All 15 new seeds are retained; no outcome-based stopping or substitution.']
    (OUT/'RESULTS.md').write_text('\n'.join(text)+'\n')
    dump(OUT/'AUDIT_FINAL.json',{'status':'PASS','new_seeds':15,'pooled_seeds':20,'new_formal_trainings':150,'new_evaluated_candidates':120,
        'protocol_sha256':digest(PROTOCOL),'pooling_audit_sha256':digest(original/'AUDIT.json'),'new_audit_sha256':digest(OUT/'AUDIT_NEW15.json'),
        'files':{str(p.relative_to(OUT)):digest(p) for p in sorted(OUT.iterdir()) if p.is_file()}})
    print('TWENTY_SEED_SENSITIVITY_AND_NEW15_PRIMARY_COMPLETE',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['new','combine']);a=p.parse_args()
    audit_new() if a.phase=='new' else combine()
