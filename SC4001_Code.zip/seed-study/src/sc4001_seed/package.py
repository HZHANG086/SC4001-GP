"""Package complete scientific evidence, excluding weights and datasets."""
import os,tarfile
from pathlib import Path
from sc4001_c.common import load,dump,digest
from .common import ROOT,PROTOCOL,specification

def main():
    spec=specification();results=Path('seed-study/results/Seeds-v1')
    audit=load(results/'AUDIT_FINAL.json')
    if audit['status']!='PASS':raise ValueError('Incomplete audit')
    for name,sha in audit['files'].items():
        if digest(results/name)!=sha:raise ValueError('Analysis changed after audit')
    paths={PROTOCOL,ROOT/'ALL_SELECTIONS_LOCKED.json',*map(Path,spec['code_sha256'])}
    paths.update(p for p in results.rglob('*') if p.is_file())
    paths.update(p for p in Path('seed-study/evidence').rglob('*') if p.is_file())
    paths.update(p for p in Path('seed-study/logs').glob('*') if p.is_file())
    for name in load(ROOT/'ALL_SELECTIONS_LOCKED.json')['candidates']:
        run=ROOT/name
        for f in ('run_config.json','validation.json','history.json','parameters.json','environment.txt','invocations.jsonl','COMPLETE'):
            paths.add(run/f)
        paths.update(p for p in (run/'evaluation').rglob('*') if p.is_file())
    paths.update(ROOT.glob('LR_LOCK-*.json'))
    paths.add(Path('seed-study/artifacts/data-v1/SEED_PREPARATION.json'))
    paths.update(Path('seed-study/artifacts/data-v1/splits').glob('b6400_s*.json'))
    paths.add(Path('seed-study/runs/JOINT_SOURCE_GATE.json'))
    paths.update(Path('pooling-study/results/Pooling-v1').glob('*'))
    paths.add(Path('pooling-study/runs/Pooling-v1/ALL_SELECTIONS_LOCKED.json'))
    for p in paths:
        if p.is_symlink() or not p.resolve().is_relative_to(Path.cwd().resolve()):raise ValueError('Unsafe archive path')
    manifest=Path('seed-study/RETURN_MANIFEST.json')
    dump(manifest,{'protocol_sha256':digest(PROTOCOL),'files':{str(p):digest(p) for p in sorted(paths)}})
    paths.add(manifest)
    target=Path(os.getenv('GP_BASE','/share/zhangh/sc4001-gp-c'))/'returns/Seeds-v1-return.tar.gz'
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():raise ValueError('Preserve existing return archive')
    temporary=target.with_suffix('.partial')
    with tarfile.open(temporary,'w:gz') as archive:
        for p in sorted(paths):archive.add(p,arcname=str(p),recursive=False)
    temporary.rename(target)
    dump(target.with_suffix('.manifest.json'),{'archive':str(target),'sha256':digest(target),'files':len(paths),'bytes':target.stat().st_size})
    print('RETURN_READY',target,flush=True)

if __name__=='__main__':main()
