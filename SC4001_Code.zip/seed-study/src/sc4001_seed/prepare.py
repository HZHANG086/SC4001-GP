"""Reproduce source eligibility, then freeze new paired splits without target labels."""
import shutil
from collections import defaultdict
from pathlib import Path
from sc4001_a.protocol import clean_source,paired_splits,text_hash
from sc4001_c.common import load,dump,digest
from sc4001_c.cka import verify_data
from .common import PROTOCOL,DATA,BASE_DATA,REFERENCE,specification,verify_prepared


def make_splits(texts,labels,test_texts,seeds):
    label_sets=defaultdict(set)
    for text,y in zip(texts,labels):label_sets[text_hash(text)].add(y)
    conflicting={h for h,ys in label_sets.items() if len(ys)>1}
    eligible,_=clean_source(texts,test_texts)
    eligible=[i for i in eligible if text_hash(texts[i]) not in conflicting]
    # Use A's complete budget list so original nesting and RNG consumption match.
    splits={s:paired_splits(labels,eligible,s)[6400] for s in seeds}
    return eligible,splits


def main():
    from datasets import load_from_disk
    spec=specification();verify_data(BASE_DATA,REFERENCE)
    if DATA.exists():verify_prepared();print('EXISTING_SEED_SPLITS_VERIFIED');return
    train=load_from_disk(str(BASE_DATA/'imdb_train'))
    # Test TEXT ONLY is used for the original decontamination rule, not fitting or scoring.
    test=load_from_disk(str(BASE_DATA/'imdb_test'))
    all_seeds=spec['original_seeds']+spec['seeds']
    eligible,splits=make_splits(train['text'],train['label'],test['text'],all_seeds)
    if len(eligible)!=24779:raise ValueError('Different source eligibility')
    for seed in spec['original_seeds']:
        old=load(BASE_DATA/'splits'/f'b6400_s{seed}.json')
        if any(old[k]!=splits[seed][k] for k in ('train_indices','validation_indices')):raise ValueError('Cannot reproduce original splits')
    DATA.parent.mkdir(parents=True,exist_ok=True)
    temporary=DATA.with_name('data-v1.partial')
    if temporary.exists():raise ValueError('Preserve incomplete data preparation for inspection')
    shutil.copytree(BASE_DATA,temporary)
    for seed in spec['seeds']:
        split=splits[seed];tr,va=split['train_indices'],split['validation_indices']
        if len(tr)!=5120 or len(va)!=1280 or set(tr)&set(va):raise ValueError('Wrong split sizes/overlap')
        if sum(train[i]['label'] for i in tr)!=2560 or sum(train[i]['label'] for i in va)!=640:raise ValueError('Unbalanced split')
        dump(temporary/'splits'/f'b6400_s{seed}.json',{'budget':6400,'seed':seed,'dataset_revision':load(BASE_DATA/'sources.json')['revisions']['imdb'],**split})
    files={str(p.relative_to(temporary)):digest(p) for p in sorted(temporary.rglob('*')) if p.is_file()}
    dump(temporary/'SEED_PREPARATION.json',{'protocol_sha256':digest(PROTOCOL),'eligible_source_rows':len(eligible),
        'original_five_splits_exactly_reproduced':True,'seeds':spec['seeds'],'files':files})
    temporary.rename(DATA);verify_prepared();print('NEW_15_PAIRED_SPLITS_FROZEN')


if __name__=='__main__':main()
