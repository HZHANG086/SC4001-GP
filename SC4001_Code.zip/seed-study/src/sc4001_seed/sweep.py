"""Source-only LR search, paired fixed-strength runs and an immutable global lock."""
import argparse,shutil,subprocess,sys,time
from pathlib import Path
from sc4001_c.common import load,dump,digest
from .common import PROTOCOL,ROOT,specification,search_candidates,study_candidates,choose,lr_path,selected_lr,validate,verify_prepared


def run_one(c,spec):
    run=ROOT/c['name'];logs=Path('seed-study/logs');logs.mkdir(parents=True,exist_ok=True)
    if (run/'COMPLETE').exists():validate(run,c,spec);return
    cmd=[sys.executable,'-m','sc4001_seed.train','--name',c['name']]
    if run.exists():
        good=[]
        for checkpoint in (run/'checkpoints').glob('checkpoint-*'):
            files=['model.safetensors','trainer_state.json','optimizer.pt','scheduler.pt','rng_state.pth']
            if all((checkpoint/f).is_file() and (checkpoint/f).stat().st_size>0 for f in files):good.append(checkpoint)
            else:checkpoint.rename(checkpoint.with_name('incomplete-'+checkpoint.name+'-'+str(time.time_ns())))
        if not good:raise ValueError('Preserve partial run without a resumable checkpoint: '+str(run))
        cmd.append('--resume')
    with (logs/(c['name']+'.log')).open('a') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
    _,v=validate(run,c,spec)
    if digest(run/'best/model.safetensors')!=v['weight_sha256']:raise ValueError('Exported weights mismatch')
    checkpoint=run/'checkpoints'
    if checkpoint.exists():
        if checkpoint.is_symlink() or not checkpoint.resolve().is_relative_to(ROOT.resolve()):raise ValueError('Unsafe pruning')
        shutil.rmtree(checkpoint)
    print('TRAINED',c['name'],flush=True)


def train_seed(seed):
    spec=specification();verify_prepared();b=6400
    if seed not in spec['seeds']:raise ValueError('Not a frozen new seed')
    if (ROOT/'ALL_SELECTIONS_LOCKED.json').exists():raise ValueError('No training after evaluation lock')
    search=search_candidates(spec,b,seed)
    for c in search:run_one(c,spec)
    if not lr_path(b,seed).exists():
        winner=choose(search,[load(ROOT/c['name']/'validation.json')['eval_accuracy'] for c in search])
        dump(lr_path(b,seed),{'protocol_sha256':digest(PROTOCOL),'winner':winner,
            'validation_sha256':{c['name']:digest(ROOT/c['name']/'validation.json') for c in search},
            'selection':'Highest IMDb validation accuracy, learning-rate list order for exact ties; shared across all heads and anchors.'})
    lr=selected_lr(b,seed)
    for c in study_candidates(spec,b,seed,lr):run_one(c,spec)


def freeze():
    spec=specification();verify_prepared();records={};eval_names=[];m6={};b=6400
    path=ROOT/'ALL_SELECTIONS_LOCKED.json'
    if path.exists():
        lock=load(path)
        if lock['protocol_sha256']!=digest(PROTOCOL):raise ValueError('Different existing lock')
        for name,entry in lock['candidates'].items():
            for f,sha in entry['files'].items():
                if digest(ROOT/name/f)!=sha:raise ValueError('Locked source evidence changed')
        return
    for seed in spec['seeds']:
        lr=selected_lr(b,seed);study=study_candidates(spec,b,seed,lr)
        all_candidates={c['name']:c for c in search_candidates(spec,b,seed)+study}
        if len(all_candidates)!=10 or len(study)!=8:raise ValueError('Incomplete per-seed design')
        for name,c in all_candidates.items():
            cfg,v=validate(ROOT/name,c,spec)
            if digest(ROOT/name/'best/model.safetensors')!=v['weight_sha256']:raise ValueError('Missing weights')
            records[name]={'candidate':c,'source_val_accuracy':v['eval_accuracy'],'weight_sha256':v['weight_sha256'],
                'files':{f:digest(ROOT/name/f) for f in ('run_config.json','validation.json','history.json')}}
        eval_names.extend(c['name'] for c in study)
        group=[c for c in study if (c['head'],c['anchor'])==('cls','mean')]
        m6[str(seed)]=choose(group,[records[c['name']]['source_val_accuracy'] for c in group])['name']
    if len(records)!=150 or len(eval_names)!=120 or len(m6)!=15:raise ValueError('Incomplete fixed-size matrix')
    dump(path,{'protocol_sha256':digest(PROTOCOL),'candidates':records,'eval_names':eval_names,'selected_names':eval_names,
        'source_selected_m6':m6,'seed_preparation_sha256':digest('seed-study/artifacts/data-v1/SEED_PREPARATION.json'),
        'lr_lock_sha256':{str(seed):digest(lr_path(b,seed)) for seed in spec['seeds']},
        'rule':'All 150 trainings, 15 source LR decisions and 15 M6 strength selections frozen before new target evaluation; evaluate 120 prespecified candidates.'})
    print('ALL_150_TRAININGS_120_EVALUATION_CANDIDATES_LOCKED',flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['train','freeze','evaluate']);p.add_argument('--seed',type=int)
    a=p.parse_args()
    if a.phase=='freeze':freeze()
    elif a.phase=='train':train_seed(a.seed)
    else:
        from .evaluate import evaluate_cell
        evaluate_cell(6400,a.seed)


if __name__=='__main__':main()
