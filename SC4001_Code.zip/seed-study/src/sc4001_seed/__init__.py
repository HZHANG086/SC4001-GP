"""Fixed-size additional-seed follow-up, separate from the original five seeds."""
