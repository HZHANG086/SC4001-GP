"""Fixed paired contrasts and separately declared multiple-testing families."""
import numpy as np
from sc4001_c.stats import paired_stats,holm
from sc4001_pool.analyze import contrasts


def effects(frame,seeds,cohort,selected_m6,fixed_lambda=.1):
    rows=[]
    for metric in ('ood_accuracy','ood_macro_f1'):
        values={}
        for head in ('cls','mean'):
            for anchor in ('none','cls','mean'):
                cell=frame[(frame['head']==head)&(frame.anchor==anchor)&(frame.strength==(0 if anchor=='none' else fixed_lambda))].sort_values('seed')
                if cell.seed.tolist()!=sorted(seeds):raise ValueError('Incorrect paired seeds')
                values[head,anchor]=cell[metric].to_numpy()*100
        comparisons=contrasts(values)
        indexed=frame.set_index('name')
        m6=np.array([indexed.loc[selected_m6[str(s)],metric]*100 for s in sorted(seeds)])
        comparisons['source_selected_m6_minus_cls_baseline']=m6-values['cls','none']
        family_rows=[]
        for comparison,d in comparisons.items():
            primary=comparison in ('matched_mean_minus_mismatched_mean','source_selected_m6_minus_cls_baseline')
            family='primary_accuracy_2' if primary and metric=='ood_accuracy' else 'secondary_accuracy_6' if metric=='ood_accuracy' else 'secondary_macro_f1_8'
            family_rows.append({'cohort':cohort,'metric':metric,'comparison':comparison,'family':family,**paired_stats(d)})
        for family in {r['family'] for r in family_rows}:
            part=[r for r in family_rows if r['family']==family]
            for row,p in zip(part,holm([r['p_signflip_exact'] for r in part])):row['p_holm_within_family']=p
        rows.extend(family_rows)
    return rows
