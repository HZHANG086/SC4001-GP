from pathlib import Path
from sc4001_c.common import load,dump,digest

PROTOCOL=Path('seed-study/protocol/Seeds-v1.json')
ROOT=Path('seed-study/runs/Seeds-v1')
DATA=Path('seed-study/artifacts/data-v1')
REFERENCE=Path('member-a/remote-records/data-v1')
BASE_DATA=Path('member-c/artifacts/data-v1')


def specification(verify=True):
    s=load(PROTOCOL)
    if s['status']!='FROZEN':raise ValueError('Protocol not frozen')
    if verify:
        for name,sha in s['code_sha256'].items():
            if digest(name)!=sha:raise ValueError('Frozen dependency changed: '+name)
    return s


def candidate(b,s,h,a,lam,lr):
    return {'name':f'b{b}-s{s}-head-{h}-anchor-{a}-lam{lam:g}-lr{lr:g}',
            'budget':b,'seed':s,'head':h,'anchor':a,'strength':lam,'lr':lr}


def study_candidates(spec,b,s,lr):
    rows=[]
    for h in ('cls','mean'):
        for a in ('none','cls','mean'):
            strengths=[0.] if a=='none' else spec['m6_lambdas'] if (h,a)==('cls','mean') else [spec['fixed_lambda']]
            rows.extend(candidate(b,s,h,a,v,lr) for v in strengths)
    return rows


def search_candidates(spec,b,s):
    return [candidate(b,s,'cls','none',0.,lr) for lr in spec['learning_rates']]


def candidates(spec,b,s):
    # CLI allowlist only. Formal nonbaseline training must also pass the LR lock.
    return [c for lr in spec['learning_rates'] for c in study_candidates(spec,b,s,lr)]


def choose(records,scores):
    if not records or len(records)!=len(scores):raise ValueError('Selection input mismatch')
    import math
    if any(not math.isfinite(v) or not 0<=v<=1 for v in scores):raise ValueError('Invalid source scores')
    return records[max(range(len(records)),key=lambda i:scores[i])]


def lr_path(b,s):return ROOT/f'LR_LOCK-b{b}-s{s}.json'


def selected_lr(b,s):
    lock=load(lr_path(b,s))
    if lock['protocol_sha256']!=digest(PROTOCOL):raise ValueError('Wrong LR protocol')
    spec=specification();records=search_candidates(spec,b,s)
    observed=[]
    for c in records:
        run=ROOT/c['name'];_,v=validate(run,c,spec)
        if digest(run/'validation.json')!=lock['validation_sha256'][c['name']]:raise ValueError('Source LR evidence changed')
        observed.append(v['eval_accuracy'])
    expected=choose(records,observed)
    if expected!=lock['winner']:raise ValueError('Incorrect source LR selection')
    return expected['lr']


def validate(folder,c,spec):
    if (folder/'COMPLETE').read_text().strip()!='FORMAL_SOURCE_ONLY_COMPLETE':raise ValueError('Not formal source training')
    cfg=load(folder/'run_config.json');v=load(folder/'validation.json')
    if cfg['candidate']!=c or cfg['protocol_sha256']!=digest(PROTOCOL) or cfg['fixture'] or cfg['smoke']:raise ValueError('Invalid candidate provenance')
    records=[r for r in load(folder/'history.json') if 'eval_accuracy' in r]
    if len(records)!=spec['epochs'] or max(r['epoch'] for r in records)!=spec['epochs']:raise ValueError('Incomplete epoch history')
    if abs(max(r['eval_accuracy'] for r in records)-v['eval_accuracy'])>1e-12:raise ValueError('Not source best')
    if v['reload_max_abs_logit_difference']>1e-6:raise ValueError('Weight reload mismatch')
    return cfg,v


def verify_prepared():
    from sc4001_c.cka import verify_data
    verify_data(DATA,REFERENCE)
    record=load(DATA/'SEED_PREPARATION.json')
    if record['protocol_sha256']!=digest(PROTOCOL) or record['eligible_source_rows']!=24779:raise ValueError('Prepared data protocol mismatch')
    for name,sha in record['files'].items():
        if digest(DATA/name)!=sha:raise ValueError('Prepared data changed: '+name)
    return record


def evaluation_candidates(spec,b,s):
    lock=load(ROOT/'ALL_SELECTIONS_LOCKED.json')
    if lock['protocol_sha256']!=digest(PROTOCOL):raise ValueError('Evaluation protocol mismatch')
    rows=[lock['candidates'][n]['candidate'] for n in lock['eval_names']
          if lock['candidates'][n]['candidate']['budget']==b and lock['candidates'][n]['candidate']['seed']==s]
    if len(rows)!=8:raise ValueError('Incomplete evaluation cell')
    return rows
