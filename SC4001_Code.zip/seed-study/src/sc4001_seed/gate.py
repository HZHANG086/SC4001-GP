"""Freeze both planned studies before either study obtains new target results."""
from pathlib import Path
from sc4001_c.common import load,dump,digest
from .common import PROTOCOL,ROOT,specification


def main():
    specification()
    from sc4001_pool.common import specification as original_spec,ROOT as original_root
    from sc4001_pool.sweep import freeze as original_freeze
    from .sweep import freeze
    if not (original_root/'ALL_SELECTIONS_LOCKED.json').exists():original_freeze(original_spec())
    freeze()
    expected={'seed_protocol_sha256':digest(PROTOCOL),
        'pooling_lock_sha256':digest(original_root/'ALL_SELECTIONS_LOCKED.json'),
        'seed_lock_sha256':digest(ROOT/'ALL_SELECTIONS_LOCKED.json'),
        'formal_candidates':360,'status':'ALL_SOURCE_SELECTIONS_LOCKED_BEFORE_NEW_TESTS'}
    path=Path('seed-study/runs/JOINT_SOURCE_GATE.json')
    if path.exists() and load(path)!=expected:raise ValueError('Joint gate changed')
    dump(path,expected);print('JOINT_SOURCE_GATE_PASS',flush=True)


if __name__=='__main__':main()
