"""Frozen-matrix evaluation, predictions, pooled/CLS CKA and probability replay."""
import gc,gzip,json,os,shutil,time
from pathlib import Path
from sc4001_c.common import load,dump,digest,write_csv
from .common import ROOT,DATA,PROTOCOL,specification,evaluation_candidates


def complete_ok(out,expected_lock):
    manifest=load(out/'EVALUATION_COMPLETE.json')
    if manifest['lock_sha256']!=expected_lock:raise ValueError('Different selection lock')
    for name,sha in manifest['files'].items():
        if digest(out/name)!=sha:raise ValueError('Evaluation checksum mismatch')
    return manifest


def evaluate_cell(budget,seed):
    import torch,numpy as np
    from datasets import load_from_disk
    from transformers import AutoTokenizer,RobertaModel
    from sc4001_c.cka import select_samples,extract,compare_features
    from sc4001_c.stats import probability_metrics
    from sc4001_pool.model import PoolingRoberta
    if not torch.cuda.is_available() or not os.getenv('SLURM_JOB_ID'):raise ValueError('Allocated GPU required')
    if '6000 Ada' not in torch.cuda.get_device_name():raise ValueError('Wrong GPU')
    from .common import verify_prepared
    verify_prepared()
    spec=specification();lock=load(ROOT/'ALL_SELECTIONS_LOCKED.json');lock_sha=digest(ROOT/'ALL_SELECTIONS_LOCKED.json')
    if lock['protocol_sha256']!=digest(PROTOCOL) or len(lock['candidates'])!=150 or len(lock['eval_names'])!=120:raise ValueError('Incomplete frozen matrix')
    torch.set_num_threads(int(os.getenv('OMP_NUM_THREADS','4')))
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    opts={'revision':spec['model_revision'],'local_files_only':True}
    tok=AutoTokenizer.from_pretrained(spec['model_id'],**opts)
    teacher=RobertaModel.from_pretrained(spec['model_id'],add_pooling_layer=False,**opts).cuda().eval()
    domains=('imdb','yelp','amazon')
    datasets={d:load_from_disk(str(DATA/f'{d}_test')) for d in domains}
    samples={d:select_samples(ds,256) for d,ds in datasets.items()}
    references={d:extract(teacher,tok,samples[d],'cuda')[0] for d in domains}
    del teacher;gc.collect();torch.cuda.empty_cache()
    for c in evaluation_candidates(spec,budget,seed):
        run=ROOT/c['name'];out=run/'evaluation'
        if (out/'EVALUATION_COMPLETE.json').exists():complete_ok(out,lock_sha);continue
        original=lock['candidates'][c['name']]
        for name in ('run_config.json','validation.json','history.json'):
            if digest(run/name)!=original['files'][name]:raise ValueError('Frozen source record changed')
        if digest(run/'best/model.safetensors')!=original['weight_sha256']:raise ValueError('Model weights changed')
        tmp=run/'evaluation.partial'
        if tmp.exists():tmp.rename(run/f'evaluation.incomplete-{time.time_ns()}')
        tmp.mkdir();model=PoolingRoberta.from_pretrained(run/'best',local_files_only=True).cuda().eval()
        if model.config.classifier_pooling!=c['head']:raise ValueError('Incorrect evaluation head')
        metrics={};cka=[];replays=[];started=time.time()
        for d,ds in datasets.items():
            ids=[];labels=[];predictions=[];positive=[]
            with gzip.open(tmp/f'{d}_predictions.jsonl.gz','wt') as f,torch.inference_mode():
                for start in range(0,len(ds),16):
                    rows=ds[start:start+16]
                    inp=tok(rows['text'],padding=True,truncation=True,max_length=512,return_tensors='pt').to('cuda')
                    probs=model(**inp).logits.softmax(-1).cpu().tolist()
                    for ident,y,prob in zip(rows['example_id'],rows['label'],probs):
                        pred=int(prob[1]>prob[0]);ids.append(ident);labels.append(y);predictions.append(pred);positive.append(prob[1])
                        f.write(json.dumps({'example_id':ident,'label':y,'prediction':pred,'p_positive':prob[1]})+'\n')
            metrics[d]={'n':len(ids),**probability_metrics(np.array(labels),np.array(predictions),np.array(positive))}
            if len(ids)!=len(set(ids)):raise ValueError('Duplicate prediction IDs')
            current,_=extract(model.roberta,tok,samples[d],'cuda')
            cka.extend(compare_features(current,references[d],{**c,'domain':d,'reference':'pretrained'}))
            # Recompute logits directly from the feature used by the saved classifier.
            feature=current[c['head']][-1]
            with torch.inference_mode():replay=model.classifier(torch.from_numpy(feature).cuda()).softmax(-1)[:,1].cpu().numpy()
            index=dict(zip(ids,positive));expected=np.array([index[r['example_id']] for r in samples[d]])
            delta=float(np.max(np.abs(replay-expected)))
            if delta>1e-4:raise ValueError('Classifier/representation replay mismatch')
            replays.append({'domain':d,'n':256,'max_abs_probability_difference':delta,
                            'sample_ids_sha256':__import__('hashlib').sha256('\n'.join(r['example_id'] for r in samples[d]).encode()).hexdigest()})
        metrics['ood_accuracy']=sum(metrics[d]['accuracy'] for d in ('yelp','amazon'))/2
        metrics['ood_macro_f1']=sum(metrics[d]['macro_f1'] for d in ('yelp','amazon'))/2
        dump(tmp/'metrics.json',metrics);write_csv(tmp/'cka.csv',cka);dump(tmp/'probability_replay.json',replays)
        files={str(p.relative_to(tmp)):digest(p) for p in sorted(tmp.iterdir()) if p.is_file()}
        dump(tmp/'EVALUATION_COMPLETE.json',{'candidate':c,'lock_sha256':lock_sha,'files':files,
            'weight_sha256':original['weight_sha256'],'job_id':os.getenv('SLURM_JOB_ID'),
            'elapsed_seconds':time.time()-started,'gpu':torch.cuda.get_device_name()})
        if out.exists():raise ValueError('Preserve existing evaluation')
        tmp.rename(out);complete_ok(out,lock_sha)
        del model;gc.collect();torch.cuda.empty_cache()
        print('EVALUATED',c['name'],flush=True)
        # Only this follow-up's source-nonselected weights; predictions + SHA remain.
        if c['name'] not in lock['selected_names']:
            best=run/'best'
            if best.is_symlink() or not best.resolve().is_relative_to(ROOT.resolve()):raise ValueError('Unsafe pruning path')
            shutil.rmtree(best)
            (run/'WEIGHTS_PRUNED').write_text('Source-nonselected follow-up weights pruned after predictions, diagnostics and checksums were saved.\n')
