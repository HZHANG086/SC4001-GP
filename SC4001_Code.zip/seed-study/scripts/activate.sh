#!/bin/bash
source pooling-study/scripts/activate.sh
export PYTHONPATH="$PWD/seed-study/src:$PYTHONPATH"
