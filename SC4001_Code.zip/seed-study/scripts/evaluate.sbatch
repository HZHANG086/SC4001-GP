#!/bin/bash
#SBATCH --partition=6000ada
#SBATCH --job-name=gp-seed-eval
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=24G
#SBATCH --time=1-12:00:00
#SBATCH --output=seed-study/logs/eval-%j.out
#SBATCH --error=seed-study/logs/eval-%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
source seed-study/scripts/activate.sh
source seed-study/scripts/job-record.sh
python - <<'PY'
import subprocess,sys
from sc4001_seed.common import specification,ROOT
from sc4001_c.common import load,digest
s=specification();gate=load('seed-study/runs/JOINT_SOURCE_GATE.json')
assert gate['seed_lock_sha256']==digest(ROOT/'ALL_SELECTIONS_LOCKED.json')
for seed in s['seeds']:subprocess.run([sys.executable,'-u','-m','sc4001_seed.sweep','evaluate','--seed',str(seed)],check=True)
PY
python -u -m sc4001_seed.analyze new
