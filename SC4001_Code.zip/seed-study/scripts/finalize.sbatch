#!/bin/bash
#SBATCH --partition=6000ada
#SBATCH --job-name=gp-seed-combine
#SBATCH --cpus-per-task=4
#SBATCH --mem=12G
#SBATCH --time=02:00:00
#SBATCH --output=seed-study/logs/final-%j.out
#SBATCH --error=seed-study/logs/final-%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
source seed-study/scripts/activate.sh
source seed-study/scripts/job-record.sh
python -u -m sc4001_seed.analyze combine
python -u -m sc4001_seed.package
