#!/bin/bash
#SBATCH --partition=6000ada
#SBATCH --job-name=gp-joint-lock
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=00:30:00
#SBATCH --output=seed-study/logs/gate-%j.out
#SBATCH --error=seed-study/logs/gate-%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
source seed-study/scripts/activate.sh
source seed-study/scripts/job-record.sh
python -u -m sc4001_seed.gate
