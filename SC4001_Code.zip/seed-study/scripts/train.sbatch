#!/bin/bash
#SBATCH --partition=6000ada
#SBATCH --job-name=gp-seed-train
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=24G
#SBATCH --time=2-00:00:00
#SBATCH --array=0-2%1
#SBATCH --output=seed-study/logs/train-%A_%a.out
#SBATCH --error=seed-study/logs/train-%A_%a.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
source seed-study/scripts/activate.sh
source seed-study/scripts/job-record.sh
python - <<'PY'
import os,subprocess,sys
from sc4001_seed.common import specification,PROTOCOL
from sc4001_c.common import load,digest
s=specification();p=load('seed-study/runs/PREFLIGHT_PASS.json')
assert p['status']=='PASS' and p['protocol_sha256']==digest(PROTOCOL)
start=int(os.environ['SLURM_ARRAY_TASK_ID'])*5
for seed in s['seeds'][start:start+5]:subprocess.run([sys.executable,'-u','-m','sc4001_seed.sweep','train','--seed',str(seed)],check=True)
PY
