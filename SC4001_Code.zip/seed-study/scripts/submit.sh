#!/bin/bash
set -euo pipefail
cd /share/zhangh/sc4001-gp-c/project
source seed-study/scripts/activate.sh
mkdir -p seed-study/logs seed-study/evidence
ledger=seed-study/evidence/slurm-submission.txt
if [[ -e "$ledger" ]]; then echo 'Submission already recorded; inspect before retrying.'; cat "$ledger"; exit 1; fi
python - <<'PY'
import subprocess
from sc4001_seed.common import specification
specification()
state=subprocess.check_output(['scontrol','show','job','12388','-o'],text=True)
if 'JobState=PENDING' not in state:raise RuntimeError('Original evaluation is not pending; do not change its gate silently')
PY
date -u +%FT%TZ > "$ledger"
prep=$(sbatch --parsable --kill-on-invalid-dep=yes --dependency=afterok:12386 seed-study/scripts/prepare.sbatch)
echo "prepare=$prep" | tee -a "$ledger"
train=$(sbatch --parsable --kill-on-invalid-dep=yes --dependency="afterok:$prep" seed-study/scripts/train.sbatch)
echo "train=$train" | tee -a "$ledger"
gate=$(sbatch --parsable --kill-on-invalid-dep=yes --dependency="afterok:12387:$train" seed-study/scripts/gate.sbatch)
echo "gate=$gate" | tee -a "$ledger"
# Only the user's pending pooling evaluation is changed, after all sources are locked.
scontrol update JobId=12388 "Dependency=afterok:$gate"
echo "original_evaluation=12388;new_dependency=afterok:$gate" | tee -a "$ledger"
evaluate=$(sbatch --parsable --kill-on-invalid-dep=yes --dependency="afterok:$gate" seed-study/scripts/evaluate.sbatch)
echo "evaluate=$evaluate" | tee -a "$ledger"
finalize=$(sbatch --parsable --kill-on-invalid-dep=yes --dependency="afterok:12388:$evaluate" seed-study/scripts/finalize.sbatch)
echo "finalize=$finalize" | tee -a "$ledger"
squeue -u zhangh -o '%.18i %.20j %.12T %.35R'
