#!/bin/bash
mkdir -p seed-study/evidence/jobs
record="seed-study/evidence/jobs/${SLURM_JOB_ID:?}.txt"
date -u +%FT%TZ >> "$record"
scontrol show job "$SLURM_JOB_ID" >> "$record"
finish() {
  code=$?
  date -u +%FT%TZ >> "$record"
  echo "shell_exit_code=$code" >> "$record"
  scontrol show job "$SLURM_JOB_ID" >> "$record" || true
  echo "EXIT_CODE=$code"
  exit "$code"
}
trap finish EXIT
