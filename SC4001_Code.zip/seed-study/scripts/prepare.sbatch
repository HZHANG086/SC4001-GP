#!/bin/bash
#SBATCH --partition=6000ada
#SBATCH --job-name=gp-seed-prepare
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --time=00:30:00
#SBATCH --output=seed-study/logs/prepare-%j.out
#SBATCH --error=seed-study/logs/prepare-%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
source seed-study/scripts/activate.sh
source seed-study/scripts/job-record.sh
python -m unittest discover -s seed-study/tests -v
python -m sc4001_seed.prepare
python - <<'PY'
import shutil
from sc4001_seed.common import specification,PROTOCOL
from sc4001_c.common import dump,digest
specification()
if shutil.disk_usage('.').free < 220*2**30:raise RuntimeError('Need 220 GiB available for both frozen studies')
dump('seed-study/runs/PREFLIGHT_PASS.json',{'status':'PASS','protocol_sha256':digest(PROTOCOL)})
PY
