"""Verify immutable source inputs and derive only scheduler/device adapter copies."""
from pathlib import Path
import difflib, hashlib, json, os, sys

run=Path(os.environ['WISTERIA_RUN'])
root=run/'project'
sha=lambda p: hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
protocol=root/'seed-study/protocol/Seeds-v1.json'
p=json.loads(protocol.read_text())
for name,expected in p['code_sha256'].items():
    if sha(root/name)!=expected:raise RuntimeError('Frozen file mismatch: '+name)
if p['seeds']!=[113,127,139,151,163,179,191,211,223,239,251,263,277,293,307] or p['budgets']!=[6400]:
    raise RuntimeError('Wrong scope')
weights=run/'cache/huggingface/hub/models--FacebookAI--roberta-base/snapshots'/p['model_revision']/'model.safetensors'
if sha(weights)!='5bde1d28afb363d0103324efeb5afc8b2b397fe5e04beabb9b1ef355255ade81':
    raise RuntimeError('Frozen pretrained weight fingerprint differs')
source=root/'seed-study/src/sc4001_seed'
overlay=run/'overlay/sc4001_seed'
overlay.mkdir(parents=True,exist_ok=False)
(overlay/'__init__.py').write_text(f'__path__.append({str(source)!r})\n')
changes={};patch=[]
for name in ('train.py','evaluate.py'):
    old=(source/name).read_text()
    if old.count("'6000 Ada' not in torch.cuda.get_device_name()")!=1 or not old.count("os.getenv('SLURM_JOB_ID')"):
        raise RuntimeError('Frozen scheduler gate is unexpected')
    new=old.replace("os.getenv('SLURM_JOB_ID')","os.getenv('PJM_JOBID')").replace(
        "'6000 Ada' not in torch.cuda.get_device_name()",
        "torch.cuda.device_count()!=1 or 'A100-SXM4-40GB' not in torch.cuda.get_device_name()")
    compile(new,str(source/name),'exec')
    (overlay/name).write_text(new)
    patch.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='frozen/'+name,tofile='overlay/'+name))
    changes[name]={'frozen_sha256':sha(source/name),'adapter_sha256':sha(overlay/name)}
record={'run_id':run.name,'gpu_stratum':'NVIDIA A100-SXM4-40GB on Wisteria Aquarius','protocol_sha256':sha(protocol),
        'model_sha256':sha(weights),'platform_adapters':changes,'seeds':p['seeds'],
        'description':'Only PJM job provenance and exact one-GPU A100 hardware checks differ. Original data, hyperparameters, losses, seeds and selection rules are frozen.',
        'statistical_scope':'New 15 are one A100 cohort. Compare with Ada five by cohort; pooled 20 is cross-hardware descriptive sensitivity, not a same-platform replication.'}
(run/'evidence/adapter.patch').write_text(''.join(patch))
(run/'evidence/platform.json').write_text(json.dumps(record,indent=2)+'\n')
print('FROZEN_CODE_AND_MODEL_VERIFIED',len(p['code_sha256']),flush=True)
