import copy,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from sc4001_c.common import dump,digest
from sc4001_seed.common import specification,search_candidates,study_candidates,choose,validate
from sc4001_seed.prepare import make_splits
from sc4001_seed.inference import effects
from sc4001_pool.evaluate import complete_ok


class SeedStudyTests(unittest.TestCase):
    def test_fixed_matrix_and_selection_ties(self):
        spec=specification(False);self.assertEqual(len(spec['seeds']),15)
        self.assertFalse(set(spec['seeds'])&set(spec['original_seeds']))
        total=[]
        for seed in spec['seeds']:
            search=search_candidates(spec,6400,seed)
            winner=choose(search,[.8,.9,.9]);self.assertEqual(winner['lr'],2e-5)
            study=study_candidates(spec,6400,seed,winner['lr'])
            self.assertEqual(len(study),8)
            fixed=[c for c in study if c['strength'] in (0.,.1)]
            self.assertEqual(len(fixed),6)
            all_runs={c['name']:c for c in search+study};self.assertEqual(len(all_runs),10)
            total.extend(all_runs)
            self.assertEqual(len({c['lr'] for c in study}),1)
        self.assertEqual(len(set(total)),150)
        with self.assertRaises(ValueError):choose(search,[.8,float('nan'),.9])

    def test_split_eligibility_pairing_and_reproducibility(self):
        texts=[f'review unique number {i}' for i in range(7000)];labels=[i%2 for i in range(7000)]
        texts += [texts[0],texts[1]];labels += [0,0] # a duplicate and a conflicting duplicate
        eligible,a=make_splits(texts,labels,[texts[3]],[13,113,127])
        eligible2,b=make_splits(texts,labels,[texts[3]],[13,113,127])
        self.assertEqual(a,b);self.assertEqual(eligible,eligible2)
        self.assertTrue({1,3,7000,7001}.isdisjoint(eligible))
        for split in a.values():
            tr,va=split['train_indices'],split['validation_indices']
            self.assertEqual(len(tr),5120);self.assertEqual(len(va),1280);self.assertFalse(set(tr)&set(va))
            self.assertEqual(sum(labels[i] for i in tr),2560);self.assertEqual(sum(labels[i] for i in va),640)
        self.assertNotEqual(a[113],a[127])

    def test_effects_and_families_do_not_confuse_head_gain(self):
        spec=specification(False);rows=[];m6={}
        for i,seed in enumerate(spec['seeds']):
            for c in study_candidates(spec,6400,seed,1e-5):
                value=.7+.1*(c['head']=='mean')+.0001*i
                if (c['head'],c['anchor'])==('cls','cls'):value+=.02
                if (c['head'],c['anchor'])==('mean','mean'):value+=.04
                rows.append({**c,'ood_accuracy':value,'ood_macro_f1':value})
                if (c['head'],c['anchor'],c['strength'])==('cls','mean',.01):m6[str(seed)]=c['name']
        out=effects(pd.DataFrame(rows),spec['seeds'],'synthetic',m6)
        primary=[r for r in out if r['family']=='primary_accuracy_2'];self.assertEqual(len(primary),2)
        self.assertEqual(sum(r['family']=='secondary_accuracy_6' for r in out),6)
        self.assertEqual(sum(r['family']=='secondary_macro_f1_8' for r in out),8)
        match=next(r for r in primary if r['comparison']=='matched_mean_minus_mismatched_mean')
        self.assertAlmostEqual(match['mean'],3.)
        self.assertEqual(match['n_seeds'],15)
        self.assertGreaterEqual(match['p_holm_within_family'],match['p_signflip_exact'])
        m=next(r for r in primary if r['comparison']=='source_selected_m6_minus_cls_baseline')
        self.assertAlmostEqual(m['mean'],0.)

    def test_prediction_manifest_detects_corruption(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);(p/'predictions').write_text('correct')
            dump(p/'EVALUATION_COMPLETE.json',{'lock_sha256':'fixed','files':{'predictions':digest(p/'predictions')}})
            complete_ok(p,'fixed')
            (p/'predictions').write_text('modified')
            with self.assertRaises(ValueError):complete_ok(p,'fixed')

    def test_synthetic_training_cannot_be_counted_as_formal(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);(p/'COMPLETE').write_text('SYNTHETIC_TEST_ONLY\n')
            with self.assertRaises(ValueError):validate(p,{},specification(False))

    def test_actual_training_lr_choice_head_export_and_resume(self):
        import torch
        from transformers import TrainerCallback
        from sc4001_pool.model import PoolingRoberta,PoolingTrainer
        from sc4001_seed.train import main
        from safetensors.torch import load_file
        sys.path.insert(0,str(Path('pooling-study/tests').resolve()))
        from fixtures import make_model,make_data
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);base=make_model(root/'base');data=make_data(root/'data')
            source=json.loads((data/'splits/b400_s13.json').read_text());source.update(budget=6400,seed=113)
            dump(data/'splits/b6400_s113.json',source)
            name='b6400-s113-head-mean-anchor-cls-lam0.1-lr1e-05'
            args=['--name',name,'--smoke','--fixture-model',str(base),'--fixture-data',str(data)]
            main(args+['--out',str(root/'continuous')])
            class Stop(TrainerCallback):
                def on_save(self,args,state,control,**kwargs):raise RuntimeError('SIMULATED_INTERRUPT')
            class Interrupted(PoolingTrainer):
                def __init__(self,*a,**kw):super().__init__(*a,**kw);self.add_callback(Stop())
            with patch('sc4001_pool.model.PoolingTrainer',Interrupted):
                with self.assertRaisesRegex(RuntimeError,'SIMULATED_INTERRUPT'):main(args+['--out',str(root/'resumed')])
            main(args+['--out',str(root/'resumed'),'--resume'])
            for location in ('best','checkpoints/checkpoint-2'):
                a=load_file(root/'continuous'/location/'model.safetensors');b=load_file(root/'resumed'/location/'model.safetensors')
                for k in a:torch.testing.assert_close(a[k],b[k],atol=0,rtol=0)
            loaded=PoolingRoberta.from_pretrained(root/'resumed/best');self.assertEqual(loaded.config.classifier_pooling,'mean')
            self.assertEqual((root/'resumed/COMPLETE').read_text().strip(),'SYNTHETIC_TEST_ONLY')
            self.assertFalse((root/'resumed/evaluation').exists())


if __name__=='__main__':unittest.main()
