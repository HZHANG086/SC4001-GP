# Additional paired seeds: Seeds-v1

This protocol is frozen before any pooling-follow-up target results. It addresses the previously declared 6400-label pooling hypothesis and the original M6-versus-full-fine-tuning comparison. It is a follow-up on already inspected datasets, not independent held-out confirmation.

The original three-budget, five-seed Pooling-v1 matrix remains unchanged. At budget 6400, add 15 prespecified seeds: 113, 127, 139, 151, 163, 179, 191, 211, 223, 239, 251, 263, 277, 293, 307. Together with 13, 21, 42, 87, 100, these provide 20 paired seeds for the focal configurations. Other budgets and methods do not become 20-seed studies.

## Per-seed design

1. Reproduce Member A's cleaned source eligibility and paired split algorithm: 5120 training and 1280 validation examples. The preparation verifies exact reproduction of all five original 6400-label splits. Test text is used only for A's pre-existing duplicate exclusion rule; no target labels or outcomes guide model development.
2. Train CLS/no-anchor baselines at learning rates 1e-5, 2e-5 and 3e-5. Select by source validation, resolving exact ties by listed order. This selected LR is shared across all heads/anchors within the seed.
3. Run the two classifier heads (CLS/mean) crossed with three anchor conditions (none/CLS/mean), with fixed regularization strength 0.1. Reuse the selected CLS baseline from step 2.
4. For the original M6 condition (CLS classifier, mean anchor), also train strengths 0.01 and 1. Select M6 strength by source validation, never by target results.

This is ten unique training candidates per new seed: three LR baselines, one mean baseline, four fixed-strength regularized cells, and two extra M6 strengths. Total: **150 new training candidates**, **120 evaluation candidates**, 4.2 million predictions, and 9360 CKA rows. All old artifacts and the already frozen Pooling-v1 code remain unchanged.

## Analysis and stopping rules

The **new 15-seed cohort** is the principal additional evidence. Report original five separately and combined twenty as sensitivity analysis. Original five inherited LR selection from V100 runs; new LR searches use Ada. All follow-up models use Ada, but upstream selection differs in hardware; disclose this when pooling cohorts.

Two co-primary accuracy contrasts are fixed: the mean matched-minus-mismatched pooling effect at lambda 0.1, and source-selected M6 minus the CLS baseline. Apply Holm correction across these two. The six other accuracy contrasts form a supporting family; eight macro-F1 contrasts form another. Report both head-specific matching directions, own-head baseline gains, individual seed differences, mean/sample SD, pointwise approximate paired-t intervals, exact sign-flip p-values and their adjusted values. Exchangeability/symmetry assumptions and repeated use of the same test datasets remain limitations.

Exactly 15 additional seeds are planned. Do not stop when significant, replace poor outcomes, change hyperparameters based on tests, treat test examples as independent training replicates, or claim equivalence from a nonsignificant result. If infrastructure prevents completion, preserve all records and label the new cohort incomplete; do not present it as the planned complete inference.

The planning precision table uses hypothetical paired SDs because the new pooling-effect variance is unknown. It does not promise detection of 0.1-point differences. Prior Ada step-time probes imply about 35 GPU-hours of new training steps alone; validation, checkpoint I/O, initialization, evaluation and queue time are additional.

## Execution and resource discipline

From the existing remote project, `bash seed-study/scripts/submit.sh` creates:

- A CPU preparation/test job after original GPU smoke 12386.
- A three-task array, five seeds per task, with **one GPU at a time**. Original pooling training also uses at most one, so up to two GPUs can work on the two studies via Slurm.
- A CPU source-selection gate after both training arrays. It freezes all 360 candidate records across both studies.
- The pending original evaluation 12388 is explicitly moved behind that gate; a new evaluation job also depends on the gate. Both evaluations may run concurrently.
- A CPU finalization job after both evaluations: independently audit new predictions, combine cohorts transparently, create figures and package return evidence.

No running jobs belonging to others are altered. No additional seeds are run on the login node. A failure blocks dependent stages; logs and checkpoint recovery preserve the same candidate rather than silently substituting it.

## Deliverables

`seed-study/results/Seeds-v1/` contains all candidate results, new-15 and pooled-20 effects, raw seedwise differences, diagnostics, plots and checksum audits. The final archive is `/share/zhangh/sc4001-gp-c/returns/Seeds-v1-return.tar.gz`; retrieve its SHA256 sidecar and the separate `Pooling-v1-return.tar.gz` as well for full reproduction. Raw datasets and model weights stay on the server. The source-selection and preparation manifests, split indices, configs, training history, per-example predictions and code are included.

Do not update numerical claims in the report before actual evidence is returned and verified. Scheduling estimates are conditional, and no experiment design guarantees full marks or statistically significant improvement.
