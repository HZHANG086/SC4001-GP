# SC4001 Group 111: Representation Preservation under Limited Labels

This package contains the training, evaluation and analysis code for the group report. The PDF is delivered separately. The included CSVs record the evaluated cells, paired effects and diagnostics. Rechecking the tables needs no GPU or model download. A new run generates checkpoints and per-example predictions from the pinned public data and pretrained model.

## Environment and data

Use Python 3.10 for GPU reproduction and a PyTorch build for the installed CUDA version. The packaged CPU checks were also tested with Python 3.12.5. Create a virtual environment, then run the following from the extracted root. Keep the directory names `member-a`, `member-b` and `member-c` unchanged; A is Sun Tingyao, B is Gao Xuran and C is Zhang Heng.

```sh
python -m pip install -r member-c/requirements-final.txt
export PROJECT_ROOT="$PWD"
export PYTHONPATH="$PROJECT_ROOT/member-a/protocol/locked_src:$PROJECT_ROOT/member-b/protocol/locked_src:$PROJECT_ROOT/member-c/src:$PROJECT_ROOT/pooling-study/src:$PROJECT_ROOT/seed-study/src"
python check_results.py
python run_tests.py
```

`check_results.py` recomputes the archived accuracy summaries and paired effects. `run_tests.py` runs all 70 CPU tests in six isolated suites, including 40 C tests for statistics, prediction integrity, CKA, LoRA, checkpoint resumption and return validation. These tests use tiny synthetic models and temporary data; they need no GPU, pretrained weights or dataset download. They do not rerun the formal experiments.

The data are IMDb (`stanfordnlp/imdb`), Yelp Polarity (`fancyzhx/yelp_polarity`) and Amazon Polarity (`fancyzhx/amazon_polarity`). `member-a/remote-records/data-v1/sources.json` pins their revisions and the `FacebookAI/roberta-base` revision. The preparation step downloads the pinned datasets, removes duplicated or overlapping source examples and reconstructs the fixed splits. Use a shared `HF_HOME` if jobs run on different nodes.

```sh
(cd member-a && python -m sc4001_a.prepare --source-lock remote-records/data-v1/sources.json)
cp -R member-a/artifacts member-b/artifacts
cp -R member-a/artifacts member-c/artifacts
```

Use these commands on a fresh extraction so the data preparation and output directories are new. Download the pinned RoBERTa snapshot into the same Hub cache before using jobs that run in offline mode.

## Original experiment

Run training and inference in allocated GPU jobs. All methods select by IMDb validation and then evaluate the specified IMDb, Yelp and Amazon test sets. The frozen JSON protocols record the grids and tie rules.

```sh
(cd member-a && python -m sc4001_a.sweep --seeds 13 21 42 87 100 --finish)
(cd member-b && for method in M3 M4 M6 L2SP; do
  python -m sc4001_b.sweep --phase "$method" --seeds 13 21 42 87 100 \
    --a-winners ../member-a/results/A-v1/winners.json || exit 1
 done && python -m sc4001_b.sweep --finish --a-winners ../member-a/results/A-v1/winners.json)
python -m sc4001_c.lora_sweep train --seed 13 21 42 87 100
python -m sc4001_c.lora_sweep freeze-selections
python -m sc4001_c.lora_sweep evaluate
python -m sc4001_c.lora_sweep collect
```

Use the selected B checkpoints and newly generated B predictions to recompute CKA. Derive the model index from the validation choices of this run.

```sh
mkdir -p reproduced
python - <<'PYTHON'
from pathlib import Path
import csv
import json

with open('reproduced/B-models.tsv', 'w', newline='') as stream:
    writer = csv.writer(stream, delimiter='\t')
    writer.writerow(['method', 'budget', 'seed', 'model_dir', 'cka_subset'])
    for path in sorted(Path('member-b/runs/B-v1').glob('selection-*.json')):
        selected = json.loads(path.read_text())
        method, budget, seed = path.stem.removeprefix('selection-').split('-')
        writer.writerow([method, budget[1:], seed[1:], selected['winner'] + '/best', 'yes'])
PYTHON
python -m sc4001_c.cka --models reproduced/B-models.tsv \
  --model-base member-b --archive member-b --data member-c/artifacts/data-v1 \
  --data-reference member-a/remote-records/data-v1 --seeds 13 21 42 87 100 \
  --out reproduced/B-CKA
python -m sc4001_c.m5_audit --b-results member-b
python -m sc4001_c.m5_cka
python -m sc4001_c.final_plots --out reproduced/figures
```

The archived `member-c/results/C-final` tables are the inputs to the last command. Historical timing and memory depend on the corresponding hardware. The original cost probes are implemented in `benchmark.py` and `m5_benchmark.py` under `member-c/src/sc4001_c`.

## Pooling and additional seeds

The Ada study uses the commands below in Slurm allocations on RTX 6000 Ada. `pooling-study/protocol/Pooling-v1.json` fixes the inherited learning rates. Run all training cells before locking selection and starting evaluation.

```sh
for cell in $(seq 0 14); do python -m sc4001_pool.sweep train --cell "$cell" || exit 1; done
python -m sc4001_pool.sweep freeze
for cell in $(seq 0 14); do python -m sc4001_pool.sweep evaluate --cell "$cell" || exit 1; done
python -m sc4001_pool.analyze
```

`seed-study/protocol/Seeds-v1.json` fixes the design for the added seeds. `python -m sc4001_seed.prepare` recreates the new splits from the prepared IMDb data. `seed-study/reference-splits/` contains the accepted indices for comparison. The historical run used single A100 SXM4 40 GB allocations on Wisteria. `seed-study/wisteria/bootstrap.py` is the original platform adapter generator. It expects `WISTERIA_RUN` with `project/`, `evidence/` and `cache/huggingface/`. Prepend `$WISTERIA_RUN/overlay` to `PYTHONPATH` after generating it. The adapter patch is included for inspection. It changes the scheduler and GPU checks.

Run from `project/`. Train each seed in a single GPU allocation. After all 15 seeds finish, freeze the choices and save the gate before running any added-seed test inference.

```sh
# In each training allocation, using one seed from Seeds-v1.json:
python -m sc4001_seed.sweep train --seed "$SC4001_SEED"
# After all training allocations complete:
python -m sc4001_seed.sweep freeze
python - <<'PYTHON'
import os
from pathlib import Path
from sc4001_c.common import digest, dump
from sc4001_seed.common import PROTOCOL, ROOT

run = Path(os.environ['WISTERIA_RUN'])
gate = Path('seed-study/runs/JOINT_SOURCE_GATE.json')
if gate.exists():
    raise SystemExit('Use the existing gate for this run')
dump(gate, {'seed_protocol_sha256': digest(PROTOCOL),
            'seed_lock_sha256': digest(ROOT / 'ALL_SELECTIONS_LOCKED.json'),
            'platform_sha256': digest(run / 'evidence/platform.json'),
            'status': 'WISTERIA_A100_ALL_SEED_SELECTIONS_LOCKED_BEFORE_TARGET'})
PYTHON
# In each evaluation allocation, using one evaluated seed:
python -m sc4001_seed.sweep evaluate --seed "$SC4001_SEED"
# After all evaluations complete:
python -m sc4001_seed.analyze new
```

Zhang Heng (C) coordinated and ran the Ada pooling follow-up and the 15-seed Wisteria follow-up with Codex assistance. Gao Xuran (B) ran the earlier B-checkpoint supplement. The report analyzes the 15 A100 seeds separately from the 5 Ada seeds.

`group-report/evidence/negative-seeds/` contains the published validation and error summaries. `group-report/scripts/analyze_negative_seeds.py --accepted-seeds DIR --out RESULTS` reruns those diagnostics against a manifest-verified full seed return. The raw step requires the full experiment records and predictions, which are outside this submission ZIP.

To regenerate the seed effect figure from the included table, run `mkdir -p group-report/latex/images` and then `python group-report/scripts/plot_seed_effects.py`. To recheck the historical return archives, pass the separate pooling and seed archives and their sidecars to `group-report/scripts/accept_supplement.py`; use `--help` for its arguments.
