"""Recalculate the main accuracy summaries and paired effects from the supplied tables."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
for name in ("member-c/src", "pooling-study/src", "seed-study/src",
             "member-a/protocol/locked_src", "member-b/protocol/locked_src"):
    sys.path.insert(0, str(ROOT / name))

import numpy as np
import pandas as pd

from sc4001_c.stats import paired_stats
from sc4001_pool.analyze import contrasts
from sc4001_seed.inference import effects


def read(name):
    return pd.read_csv(ROOT / name)


def compare(actual, expected, keys):
    actual = actual.set_index(keys).sort_index()
    expected = expected.set_index(keys).sort_index()
    pd.testing.assert_index_equal(actual.index, expected.index)
    for column in expected.columns:
        if pd.api.types.is_numeric_dtype(expected[column]):
            np.testing.assert_allclose(actual[column], expected[column], rtol=0, atol=1e-10,
                                       err_msg=column)


def main():
    final = 'member-c/results/C-final/'
    selected = read(final + 'selected_models.csv')
    assert len(selected) == 105 and not selected.duplicated(['method', 'budget', 'seed']).any()
    for domain in ('imdb', 'yelp', 'amazon', 'ood'):
        summary = selected.assign(accuracy=100 * selected[domain + '_accuracy'])
        summary = summary.groupby(['method', 'budget']).accuracy.agg(['mean', 'std', 'count'])
        compare(summary.reset_index(), read(final + domain + '_accuracy_summary.csv'), ['method', 'budget'])

    pool = 'group-report/evidence/pooling-v1/'
    rows = read(pool + 'per_candidate.csv')
    assert len(rows) == 210
    pooled = read(pool + 'paired_effects.csv')
    anchor_vectors = {}
    for head in ('cls', 'mean'):
        for anchor in ('none', 'cls', 'mean'):
            cell = rows[(rows.budget == 6400) & (rows['head'] == head) & (rows.anchor == anchor)
                        & (rows.strength == (0 if anchor == 'none' else .1))].sort_values('seed')
            assert cell.seed.tolist() == [13, 21, 42, 87, 100]
            anchor_vectors[head, anchor] = 100 * cell.ood_accuracy.to_numpy()
    focal = pooled[(pooled.metric == 'ood_accuracy') & (pooled.budget == 6400) & (pooled.strength == .1)]
    expected = focal[['comparison', 'mean', 'sample_sd', 'ci95_low', 'ci95_high', 'p_signflip_exact', 'n_seeds']]
    actual = [{'comparison': name, **paired_stats(delta)} for name, delta in contrasts(anchor_vectors).items()]
    compare(pd.DataFrame(actual), expected, ['comparison'])

    a100 = 'group-report/evidence/seeds-a100/'
    rows = read(a100 + 'per_candidate.csv')
    winners = rows[rows.source_selected_m6]
    assert len(rows) == 120 and len(winners) == 15 and winners.seed.is_unique
    lookup = dict(zip(winners.seed.astype(str), winners.name))
    actual = effects(rows, sorted(winners.seed), 'new_15_primary', lookup)
    compare(pd.DataFrame(actual), read(a100 + 'paired_effects_new15.csv'), ['metric', 'comparison'])
    print('Verified 105 original selected models, seven focal pooling contrasts, and 16 A100 paired contrasts.')


if __name__ == '__main__':
    main()
