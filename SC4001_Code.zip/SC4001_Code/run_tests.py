"""Run the packaged CPU tests without downloading models or datasets."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parent
SUITES = ('member-a', 'member-b', 'member-c', 'pooling-study', 'seed-study', 'group-report')
SOURCES = ('member-a/protocol/locked_src', 'member-b/protocol/locked_src',
           'member-c/src', 'pooling-study/src', 'seed-study/src')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite', choices=SUITES, help=argparse.SUPPRESS)
    args = parser.parse_args()
    for name in SOURCES:
        if not (ROOT / name).is_dir():
            raise SystemExit(f'Missing {name}; keep the extracted directory names unchanged.')
    os.chdir(ROOT)
    if args.suite:
        import torch
        torch.set_num_threads(1)
        sys.path[:0] = [str(ROOT / name) for name in SOURCES]
        suite = unittest.defaultTestLoader.discover(str(ROOT / args.suite / 'tests'))
        if not suite.countTestCases():
            raise SystemExit(f'No tests found for {args.suite}')
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)

    env = os.environ.copy()
    env.update(HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1',
               HF_HUB_DISABLE_TELEMETRY='1', TOKENIZERS_PARALLELISM='false',
               OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
               OPENBLAS_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    env['PYTHONPATH'] = os.pathsep.join([*(str(ROOT / name) for name in SOURCES),
                                       env.get('PYTHONPATH', '')])
    subprocess.run([sys.executable, str(ROOT / 'check_results.py')], env=env, check=True)
    for name in SUITES:
        print(f'\nRunning {name} CPU tests', flush=True)
        # Separate processes prevent the A/B/pooling fixture modules from colliding.
        subprocess.run([sys.executable, str(Path(__file__).resolve()), '--suite', name],
                       env=env, check=True, timeout=600)
    print('\nAll six CPU test suites and the archived-table checks passed.')


if __name__ == '__main__':
    main()
