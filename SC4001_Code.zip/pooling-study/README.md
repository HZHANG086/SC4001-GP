# Pooling follow-up on RTX 6000 Ada

This follow-up directly tests the pooling-mismatch hypothesis from the ABC report. It was designed after seeing the original results, so it is **not independent held-out confirmation**.

## Frozen design

Classifier pooling is CLS or masked token mean. Each has three anchor conditions: no preservation, CLS preservation, or masked-mean preservation. The linear head, full encoder training, source splits, initial pretrained revision, training schedule and per-cell learning rate are controlled. Means exclude padding and include special tokens.

- Budgets: 400, 1600, 6400. Seeds: 13, 21, 42, 87, 100.
- Fixed strengths: 0.01, 0.1, 1; the two unregularized baselines use zero.
- 210 training candidates: 30 baselines and 180 regularized candidates.
- Ten epochs per candidate; choose its checkpoint by IMDb validation accuracy.
- Freeze all candidates and 90 source-selected configurations before any new test evaluation. Evaluate all fixed-strength candidates for the planned factorial analysis.
- The primary contrast at budget 6400 and strength 0.1 is half the sum of the two head-specific matched-minus-mismatched differences. Also report both directions and gains relative to each head's unregularized baseline. A diagonal average alone is not sufficient evidence.
- Five seeds limit statistical resolution: the minimum two-sided exact sign-flip p-value is 0.0625. Report effects and uncertainty without promising significance.

`protocol/Pooling-v1.json` records the original model revision, source-only M3 learning-rate choices, provenance and frozen code hashes. This controlled comparison does not establish that the inherited learning rates are optimal for mean pooling.

## Execution

Run `bash pooling-study/scripts/submit.sh` from the existing server project. Submission creates an auditable job ledger and refuses duplicate submission. The chain is:

1. Tiny-model correctness/resume tests plus six real-model two-step GPU smoke runs.
2. A three-budget Slurm array, limited to one GPU at a time. Each budget job processes five seed cells; each cell trains all 14 paired candidates. Grouping avoids the server's 24-job global limit without changing the 210-candidate design.
3. Global source-selection lock, full test inference, representation diagnostics, independent prediction audit, figures and return archive.

Dependencies prevent later stages from running if an earlier stage fails. Jobs waiting for resources are not training. Inspect `pooling-study/evidence/slurm-submission.txt`, Slurm status and `pooling-study/logs/`.

Training can resume from complete checkpoints. Evaluation resumes verified completed candidates. Preserve incomplete artifacts for inspection. If analysis itself fails, preserve/rename its partial results folder before retrying. Never overwrite the frozen protocol after formal training begins; corrections require an explicitly recorded protocol version.

## Outputs

Each candidate saves config, epoch history, source validation result, environment, weight checksum and reload verification. Evaluation saves all 35,000 per-example predictions across IMDb/Yelp/Amazon, probability metrics, 78 layer/pooling/domain CKA rows and three probability replay checks. Across the study: 7,350,000 predictions and 16,380 CKA rows.

`results/Pooling-v1/` contains candidate metrics, aggregate results, paired effects, Holm-adjusted p-values, representation summaries, figures and audit. The return archive is `/share/zhangh/sc4001-gp-c/returns/Pooling-v1-return.tar.gz`, with checksums and scientific evidence, excluding datasets and weights. Source-selected weights remain on the server; only this study's nonselected weights are pruned after successful verified evaluation. Original A/B/C artifacts remain unchanged.

The paper must be updated only after actual results are retrieved and checked. A null or opposing result must be reported, not hidden or replaced by target-driven tuning.
