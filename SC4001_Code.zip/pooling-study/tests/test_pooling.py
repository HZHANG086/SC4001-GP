import copy,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import torch
from transformers import RobertaConfig,TrainerCallback,TrainingArguments
from sc4001_a.model import LinearRoberta
from sc4001_pool.model import pool,penalty,PoolingRoberta,PoolingTrainer
from sc4001_pool.common import candidates,specification
from sc4001_pool.analyze import contrasts


class PoolingTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1);torch.manual_seed(13)
        self.config=RobertaConfig(vocab_size=20,hidden_size=16,num_hidden_layers=2,num_attention_heads=2,intermediate_size=32,max_position_embeddings=40)
        self.x={'input_ids':torch.randint(3,20,(4,8)),'attention_mask':torch.tensor([[1,1,1,1,1,0,0,0]]*4)}

    def test_masked_mean_padding_and_gradient(self):
        h=torch.tensor([[[1.,2.],[3.,4.],[999.,999.]]],requires_grad=True)
        mask=torch.tensor([[1,1,0]])
        torch.testing.assert_close(pool(h,mask,'mean'),torch.tensor([[2.,3.]]))
        pool(h,mask,'mean').sum().backward()
        torch.testing.assert_close(h.grad[0,2],torch.zeros(2))
        with self.assertRaises(ValueError):pool(h,torch.zeros_like(mask),'mean')
        with self.assertRaises(ValueError):pool(h,mask,'wrong')

    def test_cls_baseline_identical_and_both_heads_reload(self):
        base=LinearRoberta(copy.deepcopy(self.config)).eval()
        for head in ('cls','mean'):
            cfg=copy.deepcopy(self.config);cfg.classifier_pooling=head
            model=PoolingRoberta(cfg).eval();model.load_state_dict(base.state_dict())
            with torch.no_grad():
                h=model.roberta(**self.x).last_hidden_state
                expected=model.classifier(pool(h,self.x['attention_mask'],head))
                torch.testing.assert_close(model(**self.x).logits,expected,rtol=0,atol=0)
                if head=='cls':torch.testing.assert_close(model(**self.x).logits,base(**self.x).logits,rtol=0,atol=0)
            with tempfile.TemporaryDirectory() as t:
                model.save_pretrained(t);loaded=PoolingRoberta.from_pretrained(t).eval()
                self.assertEqual(loaded.config.classifier_pooling,head)
                torch.testing.assert_close(model(**self.x).logits,loaded(**self.x).logits,rtol=0,atol=0)

    def test_penalty_identity_and_choice(self):
        a=torch.randn(3,5,8,requires_grad=True);b=a.detach().clone();b[:,1:]+=2
        mask=torch.ones(3,5,dtype=torch.long)
        self.assertLess(abs(float(penalty(a,a.detach(),mask,'mean'))),1e-6)
        self.assertLess(abs(float(penalty(a,b,mask,'cls'))),1e-6)
        loss=penalty(a,b,mask,'mean');self.assertGreater(float(loss),.01)
        loss.backward();self.assertGreater(float(a.grad.abs().sum()),0)

    def test_trainer_uses_correct_head_and_frozen_teacher(self):
        with tempfile.TemporaryDirectory() as t:
            for head in ('cls','mean'):
                for anchor in ('none','cls','mean'):
                    cfg=copy.deepcopy(self.config);cfg.classifier_pooling=head
                    model=PoolingRoberta(cfg);teacher=None if anchor=='none' else copy.deepcopy(model.roberta)
                    args=TrainingArguments(output_dir=t,use_cpu=True,report_to=[])
                    tr=PoolingTrainer(model=model,args=args,teacher=teacher,penalty_pool=anchor,strength=0 if anchor=='none' else .1)
                    self.assertFalse(tr.model_accepts_loss_kwargs)
                    model.eval();inputs={**self.x,'labels':torch.tensor([0,1,0,1])}
                    loss,out=tr.compute_loss(model,inputs,True)
                    torch.testing.assert_close(out.logits,model(**inputs).logits,rtol=0,atol=0)
                    model.train();loss=tr.compute_loss(model,inputs);loss.backward()
                    self.assertGreater(float(model.classifier.weight.grad.abs().sum()),0)
                    if teacher is not None:
                        self.assertFalse(teacher.training)
                        self.assertTrue(all(not p.requires_grad and p.grad is None for p in teacher.parameters()))

    def test_matrix_and_interaction_accounting(self):
        spec=specification(False)
        grid=[c for b in spec['budgets'] for s in spec['seeds'] for c in candidates(spec,b,s)]
        self.assertEqual(len(grid),210);self.assertEqual(len({c['name'] for c in grid}),210)
        self.assertEqual(sum(c['anchor']=='none' for c in grid),30)
        # A classifier-only gain must not masquerade as a matching effect.
        v={(h,a):np.ones(5)*(10 if h=='cls' else 20) for h in ('cls','mean') for a in ('none','cls','mean')}
        e=contrasts(v)
        self.assertTrue(all(np.array_equal(d,np.zeros(5)) for d in e.values()))
        v['cls','cls']+=2;v['mean','mean']+=4
        e=contrasts(v);np.testing.assert_equal(e['matched_mean_minus_mismatched_mean'],np.ones(5)*3)

    def test_training_export_and_exact_resume(self):
        from sc4001_pool.train import main
        sys.path.insert(0,str(Path('pooling-study/tests').resolve()))
        from fixtures import make_model,make_data
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);base=make_model(r/'base');data=make_data(r/'data')
            args=['--name','b400-s13-head-mean-anchor-cls-lam0.1','--smoke','--fixture-model',str(base),'--fixture-data',str(data)]
            main(args+['--out',str(r/'continuous')])
            class Stop(TrainerCallback):
                def on_save(self,args,state,control,**kwargs):raise RuntimeError('SIMULATED_INTERRUPT')
            class Interrupted(PoolingTrainer):
                def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.add_callback(Stop())
            with patch('sc4001_pool.model.PoolingTrainer',Interrupted):
                with self.assertRaisesRegex(RuntimeError,'SIMULATED_INTERRUPT'):main(args+['--out',str(r/'resumed')])
            main(args+['--out',str(r/'resumed'),'--resume'])
            from safetensors.torch import load_file
            a=load_file(r/'continuous/best/model.safetensors');b=load_file(r/'resumed/best/model.safetensors')
            for k in a:torch.testing.assert_close(a[k],b[k],atol=0,rtol=0)
            self.assertEqual((r/'resumed/COMPLETE').read_text().strip(),'SYNTHETIC_TEST_ONLY')
            self.assertFalse((r/'resumed/evaluation').exists())


if __name__=='__main__':unittest.main()
