"""Prospectively frozen follow-up pooling experiment; original A/B/C unchanged."""
