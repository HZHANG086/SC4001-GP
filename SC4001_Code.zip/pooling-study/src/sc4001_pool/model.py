"""Serializable CLS/mean classifier and frozen-teacher cosine objective."""
import torch
from torch.nn import functional as F
from transformers import Trainer
from transformers.modeling_outputs import SequenceClassifierOutput
from sc4001_a.model import LinearRoberta


def pool(hidden, mask, mode):
    if mode == 'cls':
        return hidden[:, 0]
    if mode != 'mean':
        raise ValueError('Unknown pooling: '+str(mode))
    if mask is None:
        raise ValueError('Masked mean requires an attention mask')
    weights = mask.unsqueeze(-1).to(hidden.dtype)
    if (weights.sum(1) <= 0).any():
        raise ValueError('Empty token mask')
    return (hidden*weights).sum(1)/weights.sum(1)


class PoolingRoberta(LinearRoberta):
    def __init__(self, config):
        config.classifier_pooling = getattr(config, 'classifier_pooling', 'cls')
        if config.classifier_pooling not in ('cls','mean'):
            raise ValueError('Invalid serialized classifier pooling')
        super().__init__(config)

    def forward(self, input_ids=None, attention_mask=None, labels=None, token_type_ids=None):
        h = self.roberta(input_ids=input_ids, attention_mask=attention_mask,
                         token_type_ids=token_type_ids, return_dict=True).last_hidden_state
        logits = self.classifier(pool(h, attention_mask, self.config.classifier_pooling))
        loss = None if labels is None else F.cross_entropy(logits, labels)
        return SequenceClassifierOutput(loss=loss, logits=logits)


def penalty(student_hidden, teacher_hidden, mask, mode):
    return (1-F.cosine_similarity(pool(student_hidden, mask, mode),
                                 pool(teacher_hidden, mask, mode),dim=-1)).mean()


class PoolingTrainer(Trainer):
    def __init__(self, *args, teacher=None, penalty_pool='none', strength=0., **kwargs):
        super().__init__(*args, **kwargs)
        if (penalty_pool == 'none') != (strength == 0.):
            raise ValueError('Baseline must use none/zero; regularization must be positive')
        if penalty_pool != 'none' and teacher is None:
            raise ValueError('Regularization requires a teacher')
        self.teacher=teacher
        self.penalty_pool=penalty_pool
        self.strength=strength
        self.components=[]
        # Match the original B custom Trainer's per-microbatch mean-loss contract.
        self.model_accepts_loss_kwargs=False
        if teacher is not None:
            teacher.eval()
            for p in teacher.parameters():p.requires_grad=False

    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        net=self.accelerator.unwrap_model(model)
        h=net.roberta(input_ids=inputs['input_ids'],attention_mask=inputs['attention_mask'],
                     token_type_ids=inputs.get('token_type_ids'),return_dict=True).last_hidden_state
        logits=net.classifier(pool(h,inputs['attention_mask'],net.config.classifier_pooling))
        ce=F.cross_entropy(logits,inputs['labels']);loss=ce
        if model.training and self.teacher is not None:
            with torch.no_grad():
                target=self.teacher(input_ids=inputs['input_ids'],attention_mask=inputs['attention_mask'],
                                    return_dict=True).last_hidden_state
            raw=penalty(h,target,inputs['attention_mask'],self.penalty_pool)
            loss=ce+self.strength*raw
            self.components.append((float(ce.detach()),float(raw.detach())))
        return (loss,SequenceClassifierOutput(loss=loss,logits=logits)) if return_outputs else loss

    def log(self, logs, *args, **kwargs):
        if self.components and 'loss' in logs:
            n=len(self.components)
            logs['train_ce']=sum(x[0] for x in self.components)/n
            logs['train_raw_penalty']=sum(x[1] for x in self.components)/n
            logs['train_weighted_penalty']=self.strength*logs['train_raw_penalty']
            self.components.clear()
        return super().log(logs,*args,**kwargs)
