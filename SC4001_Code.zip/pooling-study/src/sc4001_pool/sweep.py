"""Recoverable cell training, immutable global source selection and fixed evaluation."""
import argparse,json,os,shutil,subprocess,sys,time
from pathlib import Path
from sc4001_c.common import load,dump,digest
from .common import PROTOCOL,ROOT,DATA,REFERENCE,specification,candidates,validate


def train_cell(b,s,spec):
    from sc4001_c.cka import verify_data
    verify_data(DATA,REFERENCE)
    if (ROOT/'ALL_SELECTIONS_LOCKED.json').exists():raise ValueError('No training after global lock')
    ROOT.mkdir(parents=True,exist_ok=True)
    logs=Path('pooling-study/logs');logs.mkdir(parents=True,exist_ok=True)
    for c in candidates(spec,b,s):
        run=ROOT/c['name']
        if (run/'COMPLETE').exists():validate(run,c,spec);continue
        cmd=[sys.executable,'-m','sc4001_pool.train','--name',c['name']]
        if run.exists():
            good=[]
            for checkpoint in (run/'checkpoints').glob('checkpoint-*'):
                files=['model.safetensors','trainer_state.json','optimizer.pt','scheduler.pt','rng_state.pth']
                if all((checkpoint/f).is_file() and (checkpoint/f).stat().st_size>0 for f in files):good.append(checkpoint)
                else:checkpoint.rename(checkpoint.with_name('incomplete-'+checkpoint.name+'-'+str(time.time_ns())))
            if not good:raise ValueError('No complete resume checkpoint; preserve and inspect '+str(run))
            cmd.append('--resume')
        with (logs/(c['name']+'.log')).open('a') as f:
            subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
        _,v=validate(run,c,spec)
        if digest(run/'best/model.safetensors')!=v['weight_sha256']:raise ValueError('Weight hash mismatch')
        # Best exported and reload-verified; discard only its recoverable optimizer states.
        checkpoints=run/'checkpoints'
        if checkpoints.exists():
            if checkpoints.is_symlink() or not checkpoints.resolve().is_relative_to(ROOT.resolve()):raise ValueError('Unsafe pruning')
            shutil.rmtree(checkpoints)
        print('TRAINED',c['name'],flush=True)


def freeze(spec):
    all_records={};selected=[]
    for b in spec['budgets']:
        for s in spec['seeds']:
            records=candidates(spec,b,s)
            for c in records:
                run=ROOT/c['name'];cfg,v=validate(run,c,spec)
                if digest(run/'best/model.safetensors')!=v['weight_sha256']:raise ValueError('Missing/changed weights before lock')
                all_records[c['name']]={'candidate':c,'source_val_accuracy':v['eval_accuracy'],
                    'weight_sha256':v['weight_sha256'],'files':{n:digest(run/n) for n in ('run_config.json','validation.json','history.json')}}
            for head in ('cls','mean'):
                for anchor in ('none','cls','mean'):
                    group=[c for c in records if (c['head'],c['anchor'])==(head,anchor)]
                    winner=max(group,key=lambda c:all_records[c['name']]['source_val_accuracy'])
                    selected.append(winner['name'])
    if len(all_records)!=210 or len(selected)!=90:raise ValueError('Incomplete follow-up matrix')
    record={'protocol_sha256':digest(PROTOCOL),'candidates':all_records,'selected_names':selected,
        'rule':'All 210 candidates and 90 source-only choices frozen before new test access; all fixed-lambda cells evaluated as predefined ablations.'}
    path=ROOT/'ALL_SELECTIONS_LOCKED.json'
    if path.exists() and load(path)!=record:raise ValueError('Immutable selection lock differs')
    dump(path,record);print('ALL_210_SOURCE_TRAININGS_AND_90_CHOICES_LOCKED')


def main():
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['train','freeze','evaluate']);p.add_argument('--cell',type=int)
    a=p.parse_args();spec=specification()
    cells=[(b,s) for b in spec['run_budget_order'] for s in spec['seeds']]
    if a.phase=='freeze':freeze(spec);return
    if a.cell is None or not 0<=a.cell<len(cells):raise ValueError('Supply valid cell index')
    b,s=cells[a.cell]
    if a.phase=='train':train_cell(b,s,spec)
    else:
        from .evaluate import evaluate_cell
        evaluate_cell(b,s)


if __name__=='__main__':main()
