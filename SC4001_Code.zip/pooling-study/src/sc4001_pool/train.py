"""One candidate: training and IMDb validation only, with exact reload verification."""
import argparse,json,os,shutil,time
from contextlib import nullcontext
from pathlib import Path
from sc4001_c.common import load,dump,digest
from .common import PROTOCOL,ROOT,DATA,REFERENCE,specification,candidates


def main(argv=None):
    import torch
    import numpy as np
    from datasets import load_from_disk
    from transformers import AutoTokenizer,AutoConfig,RobertaModel,DataCollatorWithPadding,TrainingArguments,set_seed
    from sc4001_a.checkpoint import rng_serialization_context
    from sc4001_c.cka import verify_data
    from .model import PoolingRoberta,PoolingTrainer
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--name',required=True);p.add_argument('--out',type=Path)
    p.add_argument('--smoke',action='store_true');p.add_argument('--resume',action='store_true')
    p.add_argument('--fixture-model',type=Path);p.add_argument('--fixture-data',type=Path)
    a=p.parse_args(argv);fixture=a.fixture_model is not None
    if fixture != (a.fixture_data is not None) or (fixture and not a.smoke):raise ValueError('Fixture requires smoke plus model/data')
    spec=specification(verify=not fixture)
    matches=[c for b in spec['budgets'] for s in spec['seeds'] for c in candidates(spec,b,s) if c['name']==a.name]
    if len(matches)!=1:raise ValueError('Unknown frozen candidate')
    c=matches[0];out=a.out or ROOT/c['name'];data=a.fixture_data if fixture else DATA
    if not fixture:
        if not torch.cuda.is_available() or not os.getenv('SLURM_JOB_ID'):raise ValueError('Allocated CUDA job required')
        if '6000 Ada' not in torch.cuda.get_device_name():raise ValueError('Wrong GPU stratum')
        verify_data(data,REFERENCE)
        if shutil.disk_usage(out.parent if out.parent.exists() else Path('.')).free<12*2**30:raise ValueError('Less than 12 GiB free; preserve artifacts and stop')
    sources=load(data/'sources.json');split=data/'splits'/f'b{c["budget"]}_s{c["seed"]}.json'
    if not fixture and (sources['model_id'],sources['model_revision'])!=(spec['model_id'],spec['model_revision']):raise ValueError('Model provenance mismatch')
    cfg={'candidate':c,'protocol_sha256':digest(PROTOCOL),'split_sha256':digest(split),
         'data_manifest_sha256':digest(data/'manifest_hashes.json'),'smoke':a.smoke,'fixture':fixture,
         'length':32 if fixture else 512,'epochs':2 if fixture else 10}
    if out.exists():
        if not a.resume or load(out/'run_config.json')!=cfg:raise ValueError('Output exists or resume mismatch')
        if (out/'COMPLETE').exists():raise ValueError('Already complete')
    out.mkdir(parents=True,exist_ok=True);dump(out/'run_config.json',cfg)
    (out/'source').mkdir(exist_ok=True)
    for path in spec['code_sha256']:
        source=Path(path)
        # Preserve package-relative paths to avoid same-basename collisions.
        target=out/'source'/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    shutil.copy2(PROTOCOL,out/'source/protocol.json')
    from importlib.metadata import distributions
    (out/'environment.txt').write_text('\n'.join(sorted(f"{d.metadata['Name']}=={d.version}" for d in distributions()))+'\n')
    started=time.time()
    with (out/'invocations.jsonl').open('a') as f:f.write(json.dumps({'event':'start','unix_time':started,'job_id':os.getenv('SLURM_JOB_ID'),'resume':a.resume})+'\n')
    device='cpu' if fixture else 'cuda'
    torch.set_num_threads(int(os.getenv('OMP_NUM_THREADS','4')))
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    set_seed(c['seed'])
    base=str(a.fixture_model) if fixture else spec['model_id']
    opts={'revision':None if fixture else spec['model_revision'],'local_files_only':True}
    config=AutoConfig.from_pretrained(base,**opts);config.classifier_pooling=c['head']
    tok=AutoTokenizer.from_pretrained(base,**opts)
    model=PoolingRoberta.from_pretrained(base,config=config,use_safetensors=True,**opts)
    model.configure('full')
    teacher=None
    if c['anchor']!='none':
        teacher=RobertaModel.from_pretrained(base,add_pooling_layer=False,**opts).to(device).eval()
        for v in teacher.parameters():v.requires_grad=False
    params=sum(v.numel() for v in model.parameters() if v.requires_grad)
    if not fixture and params!=124056578:raise ValueError('Unexpected trainable parameter count')
    dump(out/'parameters.json',{'trainable':params,'classifier_pooling':c['head'],'penalty_pooling':c['anchor']})
    pool=load_from_disk(str(data/'imdb_train'));indices=load(split)
    def tokenize(ds):return ds.map(lambda b:tok(b['text'],truncation=True,max_length=cfg['length']),batched=True,remove_columns=['text','example_id'])
    train=tokenize(pool.select(indices['train_indices']));val=tokenize(pool.select(indices['validation_indices']))
    if fixture:train=train.select(range(32));val=val.select(range(16))
    args=TrainingArguments(output_dir=str(out/'checkpoints'),learning_rate=c['lr'],num_train_epochs=cfg['epochs'],
        max_steps=2 if a.smoke and not fixture else -1,per_device_train_batch_size=8,per_device_eval_batch_size=16,
        gradient_accumulation_steps=4,weight_decay=.01,warmup_ratio=.1,lr_scheduler_type='linear',
        adam_beta1=.9,adam_beta2=.999,adam_epsilon=1e-8,max_grad_norm=1.,
        eval_strategy='epoch',save_strategy='epoch',logging_strategy='steps',logging_steps=10,
        load_best_model_at_end=True,metric_for_best_model='accuracy',greater_is_better=True,save_total_limit=2,
        save_safetensors=True,seed=c['seed'],data_seed=c['seed'],report_to=[],use_cpu=fixture,
        fp16=False,bf16=False,dataloader_num_workers=0,optim='adamw_torch')
    trainer=PoolingTrainer(model=model,args=args,train_dataset=train,eval_dataset=val,
        processing_class=tok,data_collator=DataCollatorWithPadding(tok),teacher=teacher,
        penalty_pool=c['anchor'],strength=c['strength'],
        compute_metrics=lambda pred:{'accuracy':float(np.mean(pred.predictions.argmax(-1)==pred.label_ids))})
    # Reset after teacher construction so dropout and sampling start consistently.
    set_seed(c['seed'])
    if not fixture:torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats()
    start=time.perf_counter()
    with rng_serialization_context() if a.resume else nullcontext():
        trainer.train(resume_from_checkpoint=True if a.resume else None)
    if not fixture:torch.cuda.synchronize()
    elapsed=time.perf_counter()-start
    peak=None if fixture else torch.cuda.max_memory_allocated()/2**30
    epoch_history=list(trainer.state.log_history)
    metrics=trainer.evaluate();trainer.model.eval()
    probe=tok(pool.select(indices['validation_indices'][:8])['text'],padding=True,truncation=True,max_length=cfg['length'],return_tensors='pt').to(device)
    with torch.inference_mode():before=trainer.model(**probe).logits.cpu()
    trainer.model.save_pretrained(out/'best',safe_serialization=True);tok.save_pretrained(out/'best')
    reloaded=PoolingRoberta.from_pretrained(out/'best',local_files_only=True).to(device).eval()
    if reloaded.config.classifier_pooling!=c['head']:raise ValueError('Pooling config lost on reload')
    with torch.inference_mode():after=reloaded(**probe).logits.cpu()
    delta=float((before-after).abs().max())
    if delta>1e-6:raise ValueError('Saved-model inference mismatch')
    metrics.update({'train_seconds_this_invocation':elapsed,'peak_allocated_gib':peak,
        'reload_max_abs_logit_difference':delta,'global_step':trainer.state.global_step,
        'weight_sha256':digest(out/'best/model.safetensors'),'gpu':None if fixture else torch.cuda.get_device_name(),
        'job_id':os.getenv('SLURM_JOB_ID'),'best_checkpoint':trainer.state.best_model_checkpoint})
    dump(out/'validation.json',metrics);dump(out/'history.json',epoch_history)
    with (out/'invocations.jsonl').open('a') as f:f.write(json.dumps({'event':'success','unix_time':time.time(),'job_id':os.getenv('SLURM_JOB_ID'),'train_seconds':elapsed})+'\n')
    status='SYNTHETIC_TEST_ONLY' if fixture else 'GPU_SMOKE_ONLY' if a.smoke else 'FORMAL_SOURCE_ONLY_COMPLETE'
    (out/'COMPLETE').write_text(status+'\n');print(json.dumps(metrics,indent=2))


if __name__=='__main__':main()
