"""Independent prediction audit and preregistered fixed-strength paired contrasts."""
import gzip,json
from pathlib import Path
import numpy as np
import pandas as pd
from sc4001_c.common import load,dump,digest,write_csv
from sc4001_c.stats import probability_metrics,paired_stats,holm
from .common import ROOT,PROTOCOL,specification
from .evaluate import complete_ok


def contrasts(values):
    """Keys = (classifier pooling, anchor); values are seed-aligned vectors."""
    cc,cm=values['cls','cls'],values['cls','mean']
    mc,mm=values['mean','cls'],values['mean','mean']
    out={'cls_match_minus_mismatch':cc-cm,'mean_match_minus_mismatch':mm-mc,
         'matched_mean_minus_mismatched_mean':(cc+mm-cm-mc)/2}
    for head in ('cls','mean'):
        for anchor in ('cls','mean'):
            out[f'{head}_head_{anchor}_anchor_minus_baseline']=values[head,anchor]-values[head,'none']
    return out


def main():
    spec=specification();lock=load(ROOT/'ALL_SELECTIONS_LOCKED.json');lock_sha=digest(ROOT/'ALL_SELECTIONS_LOCKED.json')
    out=Path('pooling-study/results/Pooling-v1')
    if out.exists():raise ValueError('Keep prior analysis; choose a fresh version after investigation')
    out.mkdir(parents=True)
    records=[];cka=[];canonical={};total=0;replays=[]
    for name,entry in lock['candidates'].items():
        c=entry['candidate'];folder=ROOT/name/'evaluation';manifest=complete_ok(folder,lock_sha)
        saved=load(folder/'metrics.json');row={**c,'selected_by_source':name in lock['selected_names']}
        for domain in ('imdb','yelp','amazon'):
            with gzip.open(folder/f'{domain}_predictions.jsonl.gz','rt') as f:pred=[json.loads(line) for line in f]
            ids=[r['example_id'] for r in pred];y=np.array([r['label'] for r in pred]);p=np.array([r['p_positive'] for r in pred]);hard=np.array([r['prediction'] for r in pred])
            expected=25000 if domain=='imdb' else 5000
            if len(ids)!=expected or len(set(ids))!=expected:raise ValueError('Prediction count/identity error')
            if not np.isfinite(p).all() or ((p<0)|(p>1)).any() or not np.isin(y,[0,1]).all() or not np.isin(hard,[0,1]).all():raise ValueError('Invalid predictions')
            if ((hard!=(p>.5))&(abs(p-.5)>1e-7)).any():raise ValueError('Probability/decision mismatch')
            if domain in canonical:
                old_ids,old_y=canonical[domain]
                if ids!=old_ids or not np.array_equal(y,old_y):raise ValueError('Unpaired target IDs/labels')
            else:canonical[domain]=(ids,y)
            metrics=probability_metrics(y,hard,p)
            for key,value in metrics.items():
                if abs(value-saved[domain][key])>1e-12:raise ValueError('Independent metric mismatch')
                row[domain+'_'+key]=value
            total+=len(ids)
        for metric in ('accuracy','macro_f1'):
            row['ood_'+metric]=(row['yelp_'+metric]+row['amazon_'+metric])/2
        records.append(row);cka.append(pd.read_csv(folder/'cka.csv'))
        for replay in load(folder/'probability_replay.json'):replays.append({'name':name,**replay})
    if len(records)!=210 or total!=7350000:raise ValueError('Incomplete predictions')
    df=pd.DataFrame(records);df.to_csv(out/'per_candidate.csv',index=False)
    keys=['head','anchor','strength','budget']
    summary=df.groupby(keys)[['imdb_accuracy','yelp_accuracy','amazon_accuracy','ood_accuracy','ood_macro_f1']].agg(['mean','std','count'])
    summary.columns=['_'.join(k) for k in summary.columns];summary.to_csv(out/'summary.csv')
    effects=[]
    for metric in ('ood_accuracy','ood_macro_f1'):
        family=[]
        for budget in spec['budgets']:
            for strength in spec['lambdas']:
                values={}
                for head in ('cls','mean'):
                    for anchor in ('none','cls','mean'):
                        cell=df[(df.budget==budget)&(df['head']==head)&(df.anchor==anchor)&(df.strength==(0 if anchor=='none' else strength))].sort_values('seed')
                        if cell.seed.tolist()!=sorted(spec['seeds']):raise ValueError('Missing paired seeds')
                        values[head,anchor]=cell[metric].to_numpy()*100
                for comparison,d in contrasts(values).items():
                    family.append({'metric':metric,'budget':budget,'strength':strength,'comparison':comparison,**paired_stats(d)})
        if len(family)!=63:raise ValueError('Incomplete comparison family')
        for row,padj in zip(family,holm([r['p_signflip_exact'] for r in family])):row['p_signflip_holm_63']=padj
        effects.extend(family)
    write_csv(out/'paired_effects.csv',effects)
    all_cka=pd.concat(cka,ignore_index=True);all_cka.to_csv(out/'cka_all.csv',index=False)
    if len(all_cka)!=16380:raise ValueError('Incomplete representation matrix')
    all_cka.groupby(['budget','head','anchor','strength','domain','pooling','layer'])[['linear_cka','debiased_linear_cka','shuffled_linear_cka','cosine_distance']].mean().to_csv(out/'cka_summary.csv')
    write_csv(out/'probability_replay.csv',replays)
    if max(r['max_abs_probability_difference'] for r in replays)>1e-4:raise ValueError('Replay failure')
    # Plots encode the two matching directions separately, avoiding averaged cancellation.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,3,figsize=(11,3.3),sharey=True)
    styles=[('cls_match_minus_mismatch','CLS classifier','#0072B2','o'),('mean_match_minus_mismatch','Mean classifier','#D55E00','s')]
    e=pd.DataFrame(effects)
    for ax,b in zip(axes,spec['budgets']):
        for contrast,label,color,marker in styles:
            v=e[(e.metric=='ood_accuracy')&(e.budget==b)&(e.comparison==contrast)].sort_values('strength')
            ax.errorbar(range(3),v['mean'],yerr=[v['mean']-v.ci95_low,v.ci95_high-v['mean']],label=label,color=color,marker=marker,capsize=3)
        ax.axhline(0,color='.5',lw=.8);ax.set_xticks(range(3),['0.01','0.1','1']);ax.set_title(f'Budget {b}');ax.set_xlabel('Fixed penalty strength')
    axes[0].set_ylabel('Matched minus mismatched OOD (pp)');axes[-1].legend(frameon=False)
    fig.tight_layout();fig.savefig(out/'matching_effects.pdf');fig.savefig(out/'matching_effects.png',dpi=180);plt.close(fig)
    focal=[r for r in effects if r['metric']=='ood_accuracy' and r['budget']==6400 and r['strength']==.1 and r['comparison']=='matched_mean_minus_mismatched_mean'][0]
    dump(out/'primary_contrast.json',focal)
    (out/'RESULTS.md').write_text('# Pooling follow-up: actual results\n\nAll 210 candidates were trained before any new test evaluation. This is a follow-up designed after prior A/B/C results, not an independent held-out confirmation.\n\n'+
        f"Primary prespecified contrast (budget 6400, lambda 0.1): matched diagonal minus mismatched diagonal mean = {focal['mean']:+.3f} pp; approximate 95% paired-t interval [{focal['ci95_low']:+.3f}, {focal['ci95_high']:+.3f}]; exact sign-flip p = {focal['p_signflip_exact']:.4f}.\n\n"+
        'Interpret both classifier-specific directions, baseline-adjusted gains and all fixed strengths before attributing an effect to matching. Five seeds cannot establish equivalence or a universal mechanism. See paired_effects.csv, per_candidate.csv and cka_summary.csv.\n')
    dump(out/'AUDIT.json',{'status':'PASS','candidates':210,'prediction_files':630,'prediction_rows':total,'cka_rows':len(all_cka),
        'probability_replays':len(replays),'protocol_sha256':digest(PROTOCOL),'lock_sha256':lock_sha,
        'scope':'Independent metrics from all predictions, paired IDs, archived output hashes and frozen fixed-strength comparisons',
        'files':{str(p.relative_to(out)):digest(p) for p in sorted(out.iterdir()) if p.is_file()}})
    print('POOLING_FULL_ANALYSIS_COMPLETE',total,'prediction rows')


if __name__=='__main__':main()
