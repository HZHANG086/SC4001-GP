"""Protocol and candidate identity; no target metrics in source selection."""
from pathlib import Path
from sc4001_c.common import load,dump,digest

PROTOCOL=Path('pooling-study/protocol/Pooling-v1.json')
ROOT=Path('pooling-study/runs/Pooling-v1')
DATA=Path('member-c/artifacts/data-v1')
REFERENCE=Path('member-a/remote-records/data-v1')


def specification(verify=True):
    spec=load(PROTOCOL)
    if spec['status']!='FROZEN':raise ValueError('Protocol not frozen')
    if verify:
        for name,expected in spec['code_sha256'].items():
            if digest(Path(name))!=expected:raise ValueError('Frozen code changed: '+name)
    return spec


def candidates(spec,budget,seed):
    lr=spec['learning_rates_by_cell'][f'{budget}/{seed}']
    result=[]
    for head in ('cls','mean'):
        for anchor in ('none','cls','mean'):
            for strength in ([0.] if anchor=='none' else spec['lambdas']):
                name=f'b{budget}-s{seed}-head-{head}-anchor-{anchor}-lam{strength:g}'
                result.append({'name':name,'budget':budget,'seed':seed,'head':head,
                               'anchor':anchor,'strength':strength,'lr':lr})
    return result


def validate(folder,candidate,spec):
    if (folder/'COMPLETE').read_text().strip()!='FORMAL_SOURCE_ONLY_COMPLETE':
        raise ValueError('Formal source-only completion missing: '+str(folder))
    cfg=load(folder/'run_config.json');v=load(folder/'validation.json')
    if cfg['candidate']!=candidate or cfg['protocol_sha256']!=digest(PROTOCOL):
        raise ValueError('Config changed: '+str(folder))
    if cfg['smoke'] or cfg['fixture']:raise ValueError('Fixture/smoke is not formal')
    records=[r for r in load(folder/'history.json') if 'eval_accuracy' in r]
    if len(records)!=spec['epochs'] or max(r['epoch'] for r in records)!=spec['epochs']:
        raise ValueError('Incomplete epoch evaluation')
    if abs(max(r['eval_accuracy'] for r in records)-v['eval_accuracy'])>1e-12:
        raise ValueError('Not validation-best')
    if v['reload_max_abs_logit_difference']>1e-6:raise ValueError('Reload mismatch')
    return cfg,v
