#!/bin/bash
#SBATCH --partition=6000ada
#SBATCH --job-name=gp-pool-train
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=24G
#SBATCH --time=2-00:00:00
#SBATCH --array=0-2%1
#SBATCH --output=pooling-study/logs/train-%A_%a.out
#SBATCH --error=pooling-study/logs/train-%A_%a.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
source pooling-study/scripts/activate.sh
source pooling-study/scripts/job-record.sh
python - <<'PY'
from sc4001_c.common import load,digest
p=load('pooling-study/runs/SMOKE_PASS.json')
assert p['status']=='PASS' and p['conditions']==6
assert p['protocol_sha256']==digest('pooling-study/protocol/Pooling-v1.json')
PY
start=$(( ${SLURM_ARRAY_TASK_ID:?} * 5 ))
for ((cell=start; cell<start+5; cell++)); do
  python -u -m sc4001_pool.sweep train --cell "$cell"
done
