#!/bin/bash
#SBATCH --partition=6000ada
#SBATCH --job-name=gp-pool-eval
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=24G
#SBATCH --time=1-12:00:00
#SBATCH --output=pooling-study/logs/eval-%j.out
#SBATCH --error=pooling-study/logs/eval-%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
source pooling-study/scripts/activate.sh
source pooling-study/scripts/job-record.sh
if [[ ! -f pooling-study/runs/Pooling-v1/ALL_SELECTIONS_LOCKED.json ]]; then
  python -u -m sc4001_pool.sweep freeze
fi
for cell in {0..14}; do
  python -u -m sc4001_pool.sweep evaluate --cell "$cell"
done
python -u -m sc4001_pool.analyze
python -m sc4001_pool.package
