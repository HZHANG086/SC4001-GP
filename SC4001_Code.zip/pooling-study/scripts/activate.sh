#!/bin/bash
source member-c/scripts/ada/activate.sh
export PYTHONPATH="$PWD/pooling-study/src:$PYTHONPATH"
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
