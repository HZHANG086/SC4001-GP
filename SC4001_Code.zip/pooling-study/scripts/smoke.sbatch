#!/bin/bash
#SBATCH --partition=6000ada
#SBATCH --job-name=gp-pool-smoke
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=24G
#SBATCH --time=00:30:00
#SBATCH --output=pooling-study/logs/smoke-%j.out
#SBATCH --error=pooling-study/logs/smoke-%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
source pooling-study/scripts/activate.sh
source pooling-study/scripts/job-record.sh
python -m unittest discover -s pooling-study/tests -v
python - <<'PY'
from pathlib import Path
import shutil,subprocess,sys
from sc4001_pool.common import specification,candidates
from sc4001_c.common import load,dump,digest
if shutil.disk_usage('.').free < 130*2**30:raise RuntimeError('Need 130 GiB available before the full frozen matrix')
s=specification()
for c in candidates(s,400,13):
    if c['strength'] not in (0.,.1):continue
    out=Path('pooling-study/runs/smoke')/c['name']
    subprocess.run([sys.executable,'-m','sc4001_pool.train','--name',c['name'],'--out',str(out),'--smoke'],check=True)
    assert (out/'COMPLETE').read_text().strip()=='GPU_SMOKE_ONLY'
    v=load(out/'validation.json');assert v['global_step']==2 and v['reload_max_abs_logit_difference']<=1e-6
    shutil.rmtree(out/'checkpoints')
dump('pooling-study/runs/SMOKE_PASS.json',{'status':'PASS','conditions':6,'protocol_sha256':digest('pooling-study/protocol/Pooling-v1.json')})
PY
