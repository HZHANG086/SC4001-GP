#!/bin/bash
set -euo pipefail
cd /share/zhangh/sc4001-gp-c/project
source pooling-study/scripts/activate.sh
mkdir -p pooling-study/logs pooling-study/evidence
ledger=pooling-study/evidence/slurm-submission.txt
if [[ -e "$ledger" ]]; then echo 'Existing submission; inspect ledger before resubmitting.'; cat "$ledger"; exit 1; fi
python -c 'from sc4001_pool.common import specification; specification(); print("FROZEN_CODE_VERIFIED")'
date -u +%FT%TZ > "$ledger"
smoke=$(sbatch --parsable pooling-study/scripts/smoke.sbatch)
echo "smoke=$smoke" | tee -a "$ledger"
train=$(sbatch --parsable --kill-on-invalid-dep=yes --dependency="afterok:$smoke" pooling-study/scripts/train.sbatch)
echo "train=$train" | tee -a "$ledger"
evaluate=$(sbatch --parsable --kill-on-invalid-dep=yes --dependency="afterok:$train" pooling-study/scripts/evaluate.sbatch)
echo "evaluate=$evaluate" | tee -a "$ledger"
squeue -j "$smoke,$train,$evaluate" -o '%.18i %.20j %.12T %.30R'
