#!/bin/bash
mkdir -p pooling-study/evidence/jobs
record="pooling-study/evidence/jobs/${SLURM_JOB_ID:?}.txt"
date -u +%FT%TZ >> "$record"
scontrol show job "$SLURM_JOB_ID" >> "$record"
finish() {
  code=$?
  date -u +%FT%TZ >> "$record"
  echo "shell_exit_code=$code" >> "$record"
  scontrol show job "$SLURM_JOB_ID" >> "$record" || true
  echo "EXIT_CODE=$code"
  exit "$code"
}
trap finish EXIT
